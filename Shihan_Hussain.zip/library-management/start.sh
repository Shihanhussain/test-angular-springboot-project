#!/usr/bin/env sh
# Builds the Angular app and the Spring Boot jar, then runs it.
# All data is in memory, so every run starts with an empty library.
set -eu
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "Java 21 or newer is required, but 'java' was not found on PATH." >&2
  exit 1
fi
java_major=$(java -version 2>&1 | sed -n 's/.*version "\([0-9]*\).*/\1/p' | head -n 1)
if [ -z "$java_major" ] || [ "$java_major" -lt 21 ]; then
  echo "Java 21 or newer is required, found: $(java -version 2>&1 | head -n 1)" >&2
  exit 1
fi

echo "Building (the first run downloads Maven, Node.js and dependencies, which takes a few minutes)..."
sh ./mvnw -B --no-transfer-progress -DskipTests package

echo "Starting on http://localhost:${PORT:-8080} (Ctrl+C to stop)"
exec java -jar target/library.jar