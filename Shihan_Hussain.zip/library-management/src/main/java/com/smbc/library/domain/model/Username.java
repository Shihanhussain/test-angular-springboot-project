package com.smbc.library.domain.model;

public final class Username {

    public static final int MAX_LENGTH = 50;
    private static final String ADMIN_KEY = "admin";

    private final IdentifierText text;

    private Username(IdentifierText text) {
        this.text = text;
    }

    public static Username of(String raw) {
        return new Username(IdentifierText.parse(raw, MAX_LENGTH,
                "validation.username.required", "validation.username.too-long"));
    }

    public String display() {
        return text.display();
    }

    public boolean isAdmin() {
        return ADMIN_KEY.equals(text.key());
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Username that && text.key().equals(that.text.key());
    }

    @Override
    public int hashCode() {
        return text.key().hashCode();
    }

    @Override
    public String toString() {
        return display();
    }
}
