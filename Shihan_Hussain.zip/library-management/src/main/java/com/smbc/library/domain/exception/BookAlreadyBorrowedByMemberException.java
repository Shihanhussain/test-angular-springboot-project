package com.smbc.library.domain.exception;

import com.smbc.library.domain.model.BookTitle;

public final class BookAlreadyBorrowedByMemberException extends LibraryException {

    public BookAlreadyBorrowedByMemberException(BookTitle title) {
        super(ErrorCategory.CONFLICT, "book.already-borrowed-by-you", title.display());
    }
}