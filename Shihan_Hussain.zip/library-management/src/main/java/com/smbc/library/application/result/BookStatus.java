package com.smbc.library.application.result;

public enum BookStatus {
    AVAILABLE,
    BORROWED
}
