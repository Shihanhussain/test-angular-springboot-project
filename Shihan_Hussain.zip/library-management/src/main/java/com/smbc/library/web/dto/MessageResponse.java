package com.smbc.library.web.dto;

public record MessageResponse(String message) {
}
