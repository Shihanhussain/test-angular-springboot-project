package com.smbc.library.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SpaForwardingController {

    private static final String APP_ROUTE = "{route:^(?!api$|actuator$)[^.]*$}";

    @GetMapping({"/" + APP_ROUTE, "/" + APP_ROUTE + "/**"})
    public String forwardToApp() {
        return "forward:/index.html";
    }
}