package com.smbc.library.web.controller;

import com.smbc.library.application.result.BookSummary;
import com.smbc.library.application.service.CatalogService;
import com.smbc.library.web.dto.BookTitleRequest;
import com.smbc.library.web.dto.MessageResponse;
import com.smbc.library.web.mapper.ResponseMapper;
import com.smbc.library.web.security.AuthenticatedMember;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {

    private final CatalogService catalog;
    private final ResponseMapper mapper;

    public BookController(CatalogService catalog, ResponseMapper mapper) {
        this.catalog = catalog;
        this.mapper = mapper;
    }

    // member is unused, but asking for it makes the endpoint require a login.
    @GetMapping
    public List<BookSummary> list(AuthenticatedMember member) {
        return catalog.listBooks();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public MessageResponse add(AuthenticatedMember member, @RequestBody BookTitleRequest request) {
        return mapper.bookAdded(catalog.addBook(member.username(), request.title()));
    }
}
