package com.smbc.library.infrastructure.session;

import com.smbc.library.application.port.SessionRegistry;
import com.smbc.library.application.port.SessionToken;
import com.smbc.library.domain.model.Username;

import java.security.SecureRandom;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

// Sessions expire after a period without use, so members who close the tab without signing out
// don't leave sessions behind for the life of the process.
public class InMemorySessionRegistry implements SessionRegistry {

    private static final int TOKEN_BYTES = 32;

    private final SecureRandom random = new SecureRandom();
    private final Map<SessionToken, Session> sessions = new ConcurrentHashMap<>();
    private final Clock clock;
    private final Duration idleTimeout;

    public InMemorySessionRegistry(Clock clock, Duration idleTimeout) {
        this.clock = Objects.requireNonNull(clock, "clock");
        this.idleTimeout = Objects.requireNonNull(idleTimeout, "idleTimeout");
        if (idleTimeout.isNegative() || idleTimeout.isZero()) {
            throw new IllegalArgumentException("Idle timeout must be positive");
        }
    }

    @Override
    public SessionToken open(Username username) {
        Instant now = clock.instant();
        sessions.values().removeIf(session -> session.isExpiredAt(now, idleTimeout));
        SessionToken token = newToken();
        sessions.put(token, new Session(username, now));
        return token;
    }

    @Override
    public Optional<Username> find(SessionToken token) {
        Instant now = clock.instant();
        Session session = sessions.computeIfPresent(token,
                (key, current) -> current.isExpiredAt(now, idleTimeout) ? null : current.touchedAt(now));
        return Optional.ofNullable(session).map(Session::username);
    }

    @Override
    public Optional<Username> close(SessionToken token) {
        Instant now = clock.instant();
        return Optional.ofNullable(sessions.remove(token))
                .filter(session -> !session.isExpiredAt(now, idleTimeout))
                .map(Session::username);
    }

    private SessionToken newToken() {
        byte[] bytes = new byte[TOKEN_BYTES];
        random.nextBytes(bytes);
        return new SessionToken(Base64.getUrlEncoder().withoutPadding().encodeToString(bytes));
    }

    private record Session(Username username, Instant lastUsed) {

        boolean isExpiredAt(Instant now, Duration idleTimeout) {
            return !now.isBefore(lastUsed.plus(idleTimeout));
        }

        Session touchedAt(Instant now) {
            return new Session(username, now);
        }
    }
}
