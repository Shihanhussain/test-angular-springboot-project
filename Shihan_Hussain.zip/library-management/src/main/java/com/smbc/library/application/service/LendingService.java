package com.smbc.library.application.service;

import com.smbc.library.application.port.UnitOfWork;
import com.smbc.library.domain.model.Book;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Member;
import com.smbc.library.domain.model.Username;
import com.smbc.library.domain.repository.BookRepository;
import com.smbc.library.domain.repository.MemberRepository;

import java.util.Optional;

public class LendingService {

    private final BookRepository books;
    private final MemberRepository members;
    private final UnitOfWork unitOfWork;

    public LendingService(BookRepository books, MemberRepository members, UnitOfWork unitOfWork) {
        this.books = books;
        this.members = members;
        this.unitOfWork = unitOfWork;
    }

    public BookTitle borrow(Username borrower, String rawTitle) {
        BookTitle title = BookTitle.of(rawTitle);
        return unitOfWork.write(() -> {
            Book book = books.getByTitle(title);
            book.borrowBy(borrower);
            books.save(book);
            return book.title();
        });
    }

    public BookTitle returnBook(Username borrower, String rawTitle) {
        BookTitle title = BookTitle.of(rawTitle);
        return unitOfWork.write(() -> {
            Book book = books.getByTitle(title);
            Optional<Member> nextHolder = book.returnBy(borrower).flatMap(members::findByUsername);
            books.save(book);
            nextHolder.ifPresent(member -> {
                member.notifyHandOver(book.title());
                members.save(member);
            });
            return book.title();
        });
    }
}