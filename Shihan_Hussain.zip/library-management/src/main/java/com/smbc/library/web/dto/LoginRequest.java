package com.smbc.library.web.dto;

public record LoginRequest(String username) {
}
