package com.smbc.library.domain.repository;

import com.smbc.library.domain.exception.BookNotFoundException;
import com.smbc.library.domain.model.Book;
import com.smbc.library.domain.model.BookTitle;

import java.util.List;
import java.util.Optional;

public interface BookRepository {

    Optional<Book> findByTitle(BookTitle title);

    List<Book> findAll();

    void save(Book book);

    default Book getByTitle(BookTitle title) {
        return findByTitle(title).orElseThrow(() -> new BookNotFoundException(title));
    }
}
