package com.smbc.library.infrastructure.config;

import com.smbc.library.application.port.SessionRegistry;
import com.smbc.library.application.port.UnitOfWork;
import com.smbc.library.application.service.CatalogService;
import com.smbc.library.application.service.LendingService;
import com.smbc.library.application.service.MemberStatusService;
import com.smbc.library.application.service.MembershipService;
import com.smbc.library.application.service.WaitlistService;
import com.smbc.library.domain.repository.BookRepository;
import com.smbc.library.domain.repository.MemberRepository;
import com.smbc.library.infrastructure.persistence.InMemoryBookRepository;
import com.smbc.library.infrastructure.persistence.InMemoryMemberRepository;
import com.smbc.library.infrastructure.session.InMemorySessionRegistry;
import com.smbc.library.infrastructure.transaction.ReadWriteLockUnitOfWork;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;
import java.time.Duration;

@Configuration(proxyBeanMethods = false)
public class LibraryConfiguration {

    @Bean
    BookRepository bookRepository() {
        return new InMemoryBookRepository();
    }

    @Bean
    MemberRepository memberRepository() {
        return new InMemoryMemberRepository();
    }

    @Bean
    SessionRegistry sessionRegistry(@Value("${library.session.idle-timeout:30m}") Duration idleTimeout) {
        return new InMemorySessionRegistry(Clock.systemUTC(), idleTimeout);
    }

    @Bean
    UnitOfWork unitOfWork() {
        return new ReadWriteLockUnitOfWork();
    }

    @Bean
    MembershipService membershipService(MemberRepository members, SessionRegistry sessions,
                                        MemberStatusService memberStatus, UnitOfWork unitOfWork) {
        return new MembershipService(members, sessions, memberStatus, unitOfWork);
    }

    @Bean
    CatalogService catalogService(BookRepository books, UnitOfWork unitOfWork) {
        return new CatalogService(books, unitOfWork);
    }

    @Bean
    LendingService lendingService(BookRepository books, MemberRepository members, UnitOfWork unitOfWork) {
        return new LendingService(books, members, unitOfWork);
    }

    @Bean
    WaitlistService waitlistService(BookRepository books, UnitOfWork unitOfWork) {
        return new WaitlistService(books, unitOfWork);
    }

    @Bean
    MemberStatusService memberStatusService(BookRepository books, UnitOfWork unitOfWork) {
        return new MemberStatusService(books, unitOfWork);
    }
}
