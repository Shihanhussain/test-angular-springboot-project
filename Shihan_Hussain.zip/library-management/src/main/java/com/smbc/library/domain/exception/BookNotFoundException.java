package com.smbc.library.domain.exception;

import com.smbc.library.domain.model.BookTitle;

public final class BookNotFoundException extends LibraryException {

    public BookNotFoundException(BookTitle requestedTitle) {
        super(ErrorCategory.NOT_FOUND, "book.not-found", requestedTitle.display());
    }
}
