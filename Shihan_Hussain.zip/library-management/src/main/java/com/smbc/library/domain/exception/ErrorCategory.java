package com.smbc.library.domain.exception;

public enum ErrorCategory {
    VALIDATION,
    UNAUTHENTICATED,
    FORBIDDEN,
    NOT_FOUND,
    CONFLICT
}
