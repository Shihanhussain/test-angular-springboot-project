package com.smbc.library.web.message;

import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class UserMessages {

    private final MessageSource messageSource;

    public UserMessages(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    public String text(String key, Object... arguments) {
        return messageSource.getMessage(key, arguments, Locale.ENGLISH);
    }
}
