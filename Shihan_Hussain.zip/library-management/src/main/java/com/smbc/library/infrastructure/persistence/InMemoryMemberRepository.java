package com.smbc.library.infrastructure.persistence;

import com.smbc.library.domain.model.Member;
import com.smbc.library.domain.model.Username;
import com.smbc.library.domain.repository.MemberRepository;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class InMemoryMemberRepository implements MemberRepository {

    private final Map<Username, Member> membersByName = new HashMap<>();

    @Override
    public Optional<Member> findByUsername(Username username) {
        return Optional.ofNullable(membersByName.get(username));
    }

    @Override
    public void save(Member member) {
        membersByName.put(member.username(), member);
    }
}
