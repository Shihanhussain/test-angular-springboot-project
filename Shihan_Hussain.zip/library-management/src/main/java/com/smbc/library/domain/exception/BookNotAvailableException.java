package com.smbc.library.domain.exception;

import com.smbc.library.domain.model.BookTitle;

public final class BookNotAvailableException extends LibraryException {

    public BookNotAvailableException(BookTitle title) {
        super(ErrorCategory.CONFLICT, "book.not-available", title.display());
    }
}