package com.smbc.library.web.mapper;

import com.smbc.library.application.result.LoginResult;
import com.smbc.library.application.result.WaitlistEntry;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Username;
import com.smbc.library.web.dto.LoginNotice;
import com.smbc.library.web.dto.LoginResponse;
import com.smbc.library.web.dto.MessageResponse;
import com.smbc.library.web.message.UserMessages;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ResponseMapper {

    private final UserMessages messages;

    public ResponseMapper(UserMessages messages) {
        this.messages = messages;
    }

    public LoginResponse loginResponse(LoginResult login) {
        List<LoginNotice> notices = new ArrayList<>();
        if (login.admin()) {
            notices.add(new LoginNotice(LoginNotice.Type.ADMIN_ACCESS, messages.text("login.admin-access")));
        }
        login.handOverNotices().forEach(title -> notices.add(
                new LoginNotice(LoginNotice.Type.HAND_OVER, messages.text("login.hand-over", title.display()))));
        return new LoginResponse(login.token().value(), login.username().display(), login.admin(),
                messages.text("login.greeting", login.username().display()), List.copyOf(notices), login.status());
    }

    public MessageResponse farewell(Username username) {
        return message("logout.farewell", username.display());
    }

    public MessageResponse bookAdded(BookTitle title) {
        return message("book.added", title.display());
    }

    public MessageResponse borrowed(BookTitle title) {
        return message("loan.borrowed", title.display());
    }

    public MessageResponse returned(BookTitle title) {
        return message("loan.returned", title.display());
    }

    public MessageResponse waitlistJoined(WaitlistEntry entry) {
        return message("waitlist.joined", entry.title().display(), entry.position());
    }

    private MessageResponse message(String key, Object... arguments) {
        return new MessageResponse(messages.text(key, arguments));
    }
}