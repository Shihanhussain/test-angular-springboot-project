package com.smbc.library.application.exception;

import com.smbc.library.domain.exception.ErrorCategory;
import com.smbc.library.domain.exception.LibraryException;

public final class AdminPrivilegeRequiredException extends LibraryException {

    public AdminPrivilegeRequiredException() {
        super(ErrorCategory.FORBIDDEN, "auth.admin-required");
    }
}
