package com.smbc.library.application.exception;

import com.smbc.library.domain.exception.ErrorCategory;
import com.smbc.library.domain.exception.LibraryException;

public final class NotAuthenticatedException extends LibraryException {

    public NotAuthenticatedException() {
        super(ErrorCategory.UNAUTHENTICATED, "auth.not-authenticated");
    }
}
