package com.smbc.library.web.controller;

import com.smbc.library.application.service.LendingService;
import com.smbc.library.web.dto.BookTitleRequest;
import com.smbc.library.web.dto.MessageResponse;
import com.smbc.library.web.mapper.ResponseMapper;
import com.smbc.library.web.security.AuthenticatedMember;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class LoanController {

    private final LendingService lending;
    private final ResponseMapper mapper;

    public LoanController(LendingService lending, ResponseMapper mapper) {
        this.lending = lending;
        this.mapper = mapper;
    }

    @PostMapping("/loans")
    @ResponseStatus(HttpStatus.CREATED)
    public MessageResponse borrow(AuthenticatedMember member, @RequestBody BookTitleRequest request) {
        return mapper.borrowed(lending.borrow(member.username(), request.title()));
    }

    @PostMapping("/returns")
    public MessageResponse returnBook(AuthenticatedMember member, @RequestBody BookTitleRequest request) {
        return mapper.returned(lending.returnBook(member.username(), request.title()));
    }
}
