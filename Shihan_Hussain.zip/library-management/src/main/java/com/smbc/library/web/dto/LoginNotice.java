package com.smbc.library.web.dto;

public record LoginNotice(Type type, String message) {

    public enum Type {
        ADMIN_ACCESS,
        HAND_OVER
    }
}