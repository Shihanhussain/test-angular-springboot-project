package com.smbc.library.domain.model;

public final class BookTitle {

    public static final int MAX_LENGTH = 200;

    private final IdentifierText text;

    private BookTitle(IdentifierText text) {
        this.text = text;
    }

    public static BookTitle of(String raw) {
        return new BookTitle(IdentifierText.parse(raw, MAX_LENGTH,
                "validation.title.required", "validation.title.too-long"));
    }

    public String display() {
        return text.display();
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof BookTitle that && text.key().equals(that.text.key());
    }

    @Override
    public int hashCode() {
        return text.key().hashCode();
    }

    @Override
    public String toString() {
        return display();
    }
}
