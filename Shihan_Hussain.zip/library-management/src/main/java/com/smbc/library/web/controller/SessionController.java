package com.smbc.library.web.controller;

import com.smbc.library.application.service.MembershipService;
import com.smbc.library.web.dto.LoginRequest;
import com.smbc.library.web.dto.LoginResponse;
import com.smbc.library.web.dto.MessageResponse;
import com.smbc.library.web.mapper.ResponseMapper;
import com.smbc.library.web.security.AuthenticatedMember;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/sessions")
public class SessionController {

    private final MembershipService membership;
    private final ResponseMapper mapper;

    public SessionController(MembershipService membership, ResponseMapper mapper) {
        this.membership = membership;
        this.mapper = mapper;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public LoginResponse login(@RequestBody LoginRequest request) {
        return mapper.loginResponse(membership.login(request.username()));
    }

    @DeleteMapping("/current")
    public MessageResponse logout(AuthenticatedMember member) {
        return mapper.farewell(membership.logout(member.token()));
    }
}
