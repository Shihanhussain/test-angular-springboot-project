package com.smbc.library.web.controller;

import com.smbc.library.application.result.MemberStatus;
import com.smbc.library.application.service.MemberStatusService;
import com.smbc.library.web.security.AuthenticatedMember;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MemberStatusController {

    private final MemberStatusService memberStatus;

    public MemberStatusController(MemberStatusService memberStatus) {
        this.memberStatus = memberStatus;
    }

    @GetMapping("/api/members/me/status")
    public MemberStatus status(AuthenticatedMember member) {
        return memberStatus.statusOf(member.username());
    }
}