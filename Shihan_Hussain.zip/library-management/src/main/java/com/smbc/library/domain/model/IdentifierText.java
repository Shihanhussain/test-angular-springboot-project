package com.smbc.library.domain.model;

import com.smbc.library.domain.exception.InvalidValueException;

import java.util.Locale;
import java.util.regex.Pattern;

final class IdentifierText {

    private static final Pattern WHITESPACE_RUN = Pattern.compile("\\s+");

    private final String display;
    private final String key;

    private IdentifierText(String display) {
        this.display = display;
        this.key = display.toLowerCase(Locale.ROOT);
    }

    static IdentifierText parse(String raw, int maxLength, String requiredKey, String tooLongKey) {
        if (raw == null) {
            throw new InvalidValueException(requiredKey);
        }
        String normalised = WHITESPACE_RUN.matcher(raw.strip()).replaceAll(" ");
        if (normalised.isEmpty()) {
            throw new InvalidValueException(requiredKey);
        }
        if (normalised.length() > maxLength) {
            throw new InvalidValueException(tooLongKey, maxLength);
        }
        return new IdentifierText(normalised);
    }

    String display() {
        return display;
    }

    String key() {
        return key;
    }
}
