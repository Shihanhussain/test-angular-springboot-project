package com.smbc.library.web.dto;

import com.smbc.library.application.result.MemberStatus;

import java.util.List;

public record LoginResponse(String token, String username, boolean admin, String greeting,
                            List<LoginNotice> notices, MemberStatus status) {
}