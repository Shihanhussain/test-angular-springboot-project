package com.smbc.library.domain.exception;

import com.smbc.library.domain.model.BookTitle;

public final class AlreadyOnWaitlistException extends LibraryException {

    public AlreadyOnWaitlistException(BookTitle title, int position) {
        super(ErrorCategory.CONFLICT, "waitlist.already-joined", title.display(), position);
    }
}
