package com.smbc.library.domain.model;

import com.smbc.library.domain.exception.AlreadyOnWaitlistException;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Optional;
import java.util.OptionalInt;

// First come, first served. Positions start at 1.
final class Waitlist {

    private final BookTitle title;
    private final Deque<Username> queue = new ArrayDeque<>();

    Waitlist(BookTitle title) {
        this.title = title;
    }

    int add(Username member) {
        OptionalInt current = positionOf(member);
        if (current.isPresent()) {
            throw new AlreadyOnWaitlistException(title, current.getAsInt());
        }
        queue.addLast(member);
        return queue.size();
    }

    Optional<Username> poll() {
        return Optional.ofNullable(queue.pollFirst());
    }

    OptionalInt positionOf(Username member) {
        int position = 1;
        for (Username waiting : queue) {
            if (waiting.equals(member)) {
                return OptionalInt.of(position);
            }
            position++;
        }
        return OptionalInt.empty();
    }
}
