package com.smbc.library.application.result;

import com.smbc.library.application.port.SessionToken;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Username;

import java.util.List;

public record LoginResult(SessionToken token, Username username, boolean admin, List<BookTitle> handOverNotices,
                          MemberStatus status) {

    public LoginResult {
        handOverNotices = List.copyOf(handOverNotices);
    }
}
