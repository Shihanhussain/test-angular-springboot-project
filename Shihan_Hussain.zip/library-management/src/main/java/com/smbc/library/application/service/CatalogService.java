package com.smbc.library.application.service;

import com.smbc.library.application.port.UnitOfWork;
import com.smbc.library.application.result.BookStatus;
import com.smbc.library.application.result.BookSummary;
import com.smbc.library.application.exception.AdminPrivilegeRequiredException;
import com.smbc.library.domain.exception.BookAlreadyRegisteredException;
import com.smbc.library.domain.model.Book;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Username;
import com.smbc.library.domain.repository.BookRepository;

import java.util.List;

public class CatalogService {

    private final BookRepository books;
    private final UnitOfWork unitOfWork;

    public CatalogService(BookRepository books, UnitOfWork unitOfWork) {
        this.books = books;
        this.unitOfWork = unitOfWork;
    }

    public BookTitle addBook(Username actor, String rawTitle) {
        if (!actor.isAdmin()) {
            throw new AdminPrivilegeRequiredException();
        }
        BookTitle title = BookTitle.of(rawTitle);
        return unitOfWork.write(() -> {
            books.findByTitle(title).ifPresent(existing -> {
                throw new BookAlreadyRegisteredException(existing.title());
            });
            books.save(Book.register(title));
            return title;
        });
    }

    public List<BookSummary> listBooks() {
        return unitOfWork.read(() -> books.findAll().stream()
                .map(book -> new BookSummary(book.title(),
                        book.isAvailable() ? BookStatus.AVAILABLE : BookStatus.BORROWED))
                .toList());
    }
}
