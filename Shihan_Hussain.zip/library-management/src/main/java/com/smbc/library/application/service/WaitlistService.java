package com.smbc.library.application.service;

import com.smbc.library.application.port.UnitOfWork;
import com.smbc.library.application.result.WaitlistEntry;
import com.smbc.library.domain.model.Book;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Username;
import com.smbc.library.domain.repository.BookRepository;

public class WaitlistService {

    private final BookRepository books;
    private final UnitOfWork unitOfWork;

    public WaitlistService(BookRepository books, UnitOfWork unitOfWork) {
        this.books = books;
        this.unitOfWork = unitOfWork;
    }

    public WaitlistEntry join(Username member, String rawTitle) {
        BookTitle title = BookTitle.of(rawTitle);
        return unitOfWork.write(() -> {
            Book book = books.getByTitle(title);
            int position = book.addToWaitlist(member);
            books.save(book);
            return new WaitlistEntry(book.title(), position);
        });
    }
}
