package com.smbc.library.application.result;

import com.smbc.library.domain.model.BookTitle;

public record BookSummary(BookTitle title, BookStatus status) {
}
