package com.smbc.library.domain.exception;

import com.smbc.library.domain.model.BookTitle;

public final class BookAvailableForBorrowingException extends LibraryException {

    public BookAvailableForBorrowingException(BookTitle title) {
        super(ErrorCategory.CONFLICT, "waitlist.book-available", title.display());
    }
}