package com.smbc.library.application.port;

import com.smbc.library.domain.model.Username;

import java.util.Optional;

public interface SessionRegistry {

    SessionToken open(Username username);

    Optional<Username> find(SessionToken token);

    Optional<Username> close(SessionToken token);
}
