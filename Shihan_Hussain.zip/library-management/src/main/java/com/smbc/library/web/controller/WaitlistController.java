package com.smbc.library.web.controller;

import com.smbc.library.application.service.WaitlistService;
import com.smbc.library.web.dto.BookTitleRequest;
import com.smbc.library.web.dto.MessageResponse;
import com.smbc.library.web.mapper.ResponseMapper;
import com.smbc.library.web.security.AuthenticatedMember;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/waitlist-entries")
public class WaitlistController {

    private final WaitlistService waitlist;
    private final ResponseMapper mapper;

    public WaitlistController(WaitlistService waitlist, ResponseMapper mapper) {
        this.waitlist = waitlist;
        this.mapper = mapper;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public MessageResponse join(AuthenticatedMember member, @RequestBody BookTitleRequest request) {
        return mapper.waitlistJoined(waitlist.join(member.username(), request.title()));
    }
}
