package com.smbc.library.domain.exception;

public final class InvalidValueException extends LibraryException {

    public InvalidValueException(String messageKey, Object... messageArguments) {
        super(ErrorCategory.VALIDATION, messageKey, messageArguments);
    }
}
