package com.smbc.library.domain.exception;

import com.smbc.library.domain.model.BookTitle;

public final class BookAlreadyRegisteredException extends LibraryException {

    public BookAlreadyRegisteredException(BookTitle registeredTitle) {
        super(ErrorCategory.CONFLICT, "book.already-registered", registeredTitle.display());
    }
}
