package com.smbc.library.domain.model;

import com.smbc.library.domain.exception.BookAlreadyBorrowedByMemberException;
import com.smbc.library.domain.exception.BookAvailableForBorrowingException;
import com.smbc.library.domain.exception.BookNotAvailableException;
import com.smbc.library.domain.exception.BookNotBorrowedByMemberException;

import java.util.Objects;
import java.util.Optional;
import java.util.OptionalInt;

// One copy per title. An available book never has a wait list, because a return
// goes straight to whoever is first in line.
public final class Book {

    private final BookTitle title;
    private final Waitlist waitlist;
    private Username borrower;

    private Book(BookTitle title) {
        this.title = Objects.requireNonNull(title, "title");
        this.waitlist = new Waitlist(title);
    }

    public static Book register(BookTitle title) {
        return new Book(title);
    }

    public BookTitle title() {
        return title;
    }

    public boolean isAvailable() {
        return borrower == null;
    }

    public boolean isBorrowedBy(Username member) {
        return member.equals(borrower);
    }

    public void borrowBy(Username member) {
        if (isBorrowedBy(member)) {
            throw new BookAlreadyBorrowedByMemberException(title);
        }
        if (!isAvailable()) {
            throw new BookNotAvailableException(title);
        }
        borrower = member;
    }

    // Returns who got the book next, or empty if it's back on the shelf.
    public Optional<Username> returnBy(Username member) {
        if (!isBorrowedBy(member)) {
            throw new BookNotBorrowedByMemberException(title);
        }
        Optional<Username> nextHolder = waitlist.poll();
        borrower = nextHolder.orElse(null);
        return nextHolder;
    }

    public int addToWaitlist(Username member) {
        if (isBorrowedBy(member)) {
            throw new BookAlreadyBorrowedByMemberException(title);
        }
        if (isAvailable()) {
            throw new BookAvailableForBorrowingException(title);
        }
        return waitlist.add(member);
    }

    public OptionalInt waitlistPositionOf(Username member) {
        return waitlist.positionOf(member);
    }
}
