package com.smbc.library.domain.exception;

import java.util.Arrays;

public abstract class LibraryException extends RuntimeException {

    private final ErrorCategory category;
    private final String messageKey;
    private final transient Object[] messageArguments;

    protected LibraryException(ErrorCategory category, String messageKey, Object... messageArguments) {
        super(messageKey + Arrays.toString(messageArguments));
        this.category = category;
        this.messageKey = messageKey;
        this.messageArguments = messageArguments.clone();
    }

    public ErrorCategory category() {
        return category;
    }

    public String messageKey() {
        return messageKey;
    }

    public Object[] messageArguments() {
        return messageArguments.clone();
    }
}
