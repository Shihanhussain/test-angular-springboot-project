package com.smbc.library.infrastructure.transaction;

import com.smbc.library.application.port.UnitOfWork;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Supplier;

// Writes are exclusive so "is it available? then borrow" can't race between two requests.
// Fair mode so a steady stream of reads can't starve a write.
public class ReadWriteLockUnitOfWork implements UnitOfWork {

    private final ReadWriteLock lock = new ReentrantReadWriteLock(true);

    @Override
    public <T> T read(Supplier<T> work) {
        return runWith(lock.readLock(), work);
    }

    @Override
    public <T> T write(Supplier<T> work) {
        return runWith(lock.writeLock(), work);
    }

    private static <T> T runWith(Lock held, Supplier<T> work) {
        held.lock();
        try {
            return work.get();
        } finally {
            held.unlock();
        }
    }
}
