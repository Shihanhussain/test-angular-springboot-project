package com.smbc.library.web.dto;

public record BookTitleRequest(String title) {
}
