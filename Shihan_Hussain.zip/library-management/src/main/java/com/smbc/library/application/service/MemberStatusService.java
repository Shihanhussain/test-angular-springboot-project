package com.smbc.library.application.service;

import com.smbc.library.application.port.UnitOfWork;
import com.smbc.library.application.result.MemberStatus;
import com.smbc.library.application.result.WaitlistEntry;
import com.smbc.library.domain.model.Book;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Username;
import com.smbc.library.domain.repository.BookRepository;

import java.util.ArrayList;
import java.util.List;

// Status is worked out from the books every time instead of being stored per member,
// so the two can't get out of sync. It's a full scan, which is fine for a small library.
public class MemberStatusService {

    private final BookRepository books;
    private final UnitOfWork unitOfWork;

    public MemberStatusService(BookRepository books, UnitOfWork unitOfWork) {
        this.books = books;
        this.unitOfWork = unitOfWork;
    }

    public MemberStatus statusOf(Username member) {
        return unitOfWork.read(() -> currentStatusOf(member));
    }

    // For callers that already hold a unit of work, such as login.
    MemberStatus currentStatusOf(Username member) {
        List<BookTitle> borrowed = new ArrayList<>();
        List<WaitlistEntry> waitlists = new ArrayList<>();
        for (Book book : books.findAll()) {
            if (book.isBorrowedBy(member)) {
                borrowed.add(book.title());
            }
            book.waitlistPositionOf(member)
                    .ifPresent(position -> waitlists.add(new WaitlistEntry(book.title(), position)));
        }
        return new MemberStatus(borrowed, waitlists);
    }
}
