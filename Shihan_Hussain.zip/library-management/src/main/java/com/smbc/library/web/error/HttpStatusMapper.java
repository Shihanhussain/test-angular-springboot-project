package com.smbc.library.web.error;

import com.smbc.library.domain.exception.ErrorCategory;
import org.springframework.http.HttpStatus;

final class HttpStatusMapper {

    private HttpStatusMapper() {
    }

    static HttpStatus statusOf(ErrorCategory category) {
        return switch (category) {
            case VALIDATION -> HttpStatus.BAD_REQUEST;
            case UNAUTHENTICATED -> HttpStatus.UNAUTHORIZED;
            case FORBIDDEN -> HttpStatus.FORBIDDEN;
            case NOT_FOUND -> HttpStatus.NOT_FOUND;
            case CONFLICT -> HttpStatus.CONFLICT;
        };
    }
}
