package com.smbc.library.web.config;

import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.smbc.library.application.service.MembershipService;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.web.security.AuthenticatedMemberArgumentResolver;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.List;

@Configuration(proxyBeanMethods = false)
public class WebConfig implements WebMvcConfigurer {

    private final MembershipService membership;

    public WebConfig(MembershipService membership) {
        this.membership = membership;
    }

    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
        resolvers.add(new AuthenticatedMemberArgumentResolver(membership));
    }

    // Lets the API return application results directly: a BookTitle is written as its display text.
    @Bean
    Jackson2ObjectMapperBuilderCustomizer bookTitleAsText() {
        return builder -> builder.serializerByType(BookTitle.class, ToStringSerializer.instance);
    }
}