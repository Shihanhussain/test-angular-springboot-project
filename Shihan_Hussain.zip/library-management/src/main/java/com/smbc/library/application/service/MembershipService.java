package com.smbc.library.application.service;

import com.smbc.library.application.exception.NotAuthenticatedException;
import com.smbc.library.application.port.SessionRegistry;
import com.smbc.library.application.port.SessionToken;
import com.smbc.library.application.port.UnitOfWork;
import com.smbc.library.application.result.LoginResult;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Member;
import com.smbc.library.domain.model.Username;
import com.smbc.library.domain.repository.MemberRepository;

import java.util.List;

public class MembershipService {

    private final MemberRepository members;
    private final SessionRegistry sessions;
    private final MemberStatusService memberStatus;
    private final UnitOfWork unitOfWork;

    public MembershipService(MemberRepository members, SessionRegistry sessions, MemberStatusService memberStatus,
                             UnitOfWork unitOfWork) {
        this.members = members;
        this.sessions = sessions;
        this.memberStatus = memberStatus;
        this.unitOfWork = unitOfWork;
    }

    public LoginResult login(String rawUsername) {
        Username username = Username.of(rawUsername);
        return unitOfWork.write(() -> {
            Member member = members.findByUsername(username).orElseGet(() -> Member.register(username));
            List<BookTitle> handOverNotices = member.collectHandOverNotices();
            members.save(member);
            return new LoginResult(sessions.open(member.username()), member.username(),
                    member.isAdmin(), handOverNotices, memberStatus.currentStatusOf(member.username()));
        });
    }

    public Username logout(SessionToken token) {
        return sessions.close(token).orElseThrow(NotAuthenticatedException::new);
    }

    public Username authenticate(SessionToken token) {
        return sessions.find(token).orElseThrow(NotAuthenticatedException::new);
    }
}
