package com.smbc.library.web.security;

import com.smbc.library.application.exception.NotAuthenticatedException;
import com.smbc.library.application.port.SessionToken;
import com.smbc.library.application.service.MembershipService;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

public class AuthenticatedMemberArgumentResolver implements HandlerMethodArgumentResolver {

    private static final String BEARER_PREFIX = "Bearer ";

    private final MembershipService membership;

    public AuthenticatedMemberArgumentResolver(MembershipService membership) {
        this.membership = membership;
    }

    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        return AuthenticatedMember.class.equals(parameter.getParameterType());
    }

    @Override
    public AuthenticatedMember resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer,
                                               NativeWebRequest request, WebDataBinderFactory binderFactory) {
        SessionToken token = bearerToken(request.getHeader(HttpHeaders.AUTHORIZATION));
        return new AuthenticatedMember(token, membership.authenticate(token));
    }

    private static SessionToken bearerToken(String header) {
        if (header == null || !header.regionMatches(true, 0, BEARER_PREFIX, 0, BEARER_PREFIX.length())) {
            throw new NotAuthenticatedException();
        }
        String value = header.substring(BEARER_PREFIX.length()).strip();
        if (value.isEmpty()) {
            throw new NotAuthenticatedException();
        }
        return new SessionToken(value);
    }
}
