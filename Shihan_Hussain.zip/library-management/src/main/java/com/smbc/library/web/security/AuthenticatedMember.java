package com.smbc.library.web.security;

import com.smbc.library.application.port.SessionToken;
import com.smbc.library.domain.model.Username;

public record AuthenticatedMember(SessionToken token, Username username) {
}
