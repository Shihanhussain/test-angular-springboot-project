package com.smbc.library.application.result;

import com.smbc.library.domain.model.BookTitle;

import java.util.List;

public record MemberStatus(List<BookTitle> borrowedBooks, List<WaitlistEntry> waitlists) {

    public MemberStatus {
        borrowedBooks = List.copyOf(borrowedBooks);
        waitlists = List.copyOf(waitlists);
    }
}
