package com.smbc.library.application.port;

import java.util.function.Supplier;

public interface UnitOfWork {

    <T> T read(Supplier<T> work);

    <T> T write(Supplier<T> work);
}
