package com.smbc.library.application.port;

import java.util.Objects;

public record SessionToken(String value) {

    public SessionToken {
        Objects.requireNonNull(value, "value");
        if (value.isBlank()) {
            throw new IllegalArgumentException("Session token must not be blank");
        }
    }

    @Override
    public String toString() {
        return "SessionToken[***]";
    }
}
