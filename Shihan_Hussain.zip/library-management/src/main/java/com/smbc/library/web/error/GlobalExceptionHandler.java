package com.smbc.library.web.error;

import com.smbc.library.domain.exception.LibraryException;
import com.smbc.library.web.message.UserMessages;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private final UserMessages messages;

    public GlobalExceptionHandler(UserMessages messages) {
        this.messages = messages;
    }

    @ExceptionHandler(LibraryException.class)
    ResponseEntity<ApiErrorResponse> handleBusinessError(LibraryException error) {
        return respond(HttpStatusMapper.statusOf(error.category()), error.messageKey(), error.messageArguments());
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    ResponseEntity<ApiErrorResponse> handleUnreadableBody() {
        return respond(HttpStatus.BAD_REQUEST, "request.malformed");
    }

    @ExceptionHandler(NoResourceFoundException.class)
    ResponseEntity<ApiErrorResponse> handleUnknownRoute() {
        return respond(HttpStatus.NOT_FOUND, "request.not-found");
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    ResponseEntity<ApiErrorResponse> handleUnsupportedMethod() {
        return respond(HttpStatus.METHOD_NOT_ALLOWED, "request.method-not-allowed");
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    ResponseEntity<ApiErrorResponse> handleUnsupportedMediaType() {
        return respond(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "request.unsupported-media-type");
    }

    @ExceptionHandler(Exception.class)
    ResponseEntity<ApiErrorResponse> handleUnexpected(Exception error) {
        log.error("Unexpected failure while handling a request", error);
        return respond(HttpStatus.INTERNAL_SERVER_ERROR, "server.unexpected");
    }

    private ResponseEntity<ApiErrorResponse> respond(HttpStatus status, String key, Object... arguments) {
        return ResponseEntity.status(status).body(new ApiErrorResponse(key, messages.text(key, arguments)));
    }
}
