package com.smbc.library.web.error;

public record ApiErrorResponse(String code, String message) {
}
