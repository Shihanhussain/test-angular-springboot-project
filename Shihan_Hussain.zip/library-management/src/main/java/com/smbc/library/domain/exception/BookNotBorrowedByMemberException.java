package com.smbc.library.domain.exception;

import com.smbc.library.domain.model.BookTitle;

public final class BookNotBorrowedByMemberException extends LibraryException {

    public BookNotBorrowedByMemberException(BookTitle title) {
        super(ErrorCategory.CONFLICT, "book.not-borrowed-by-you", title.display());
    }
}