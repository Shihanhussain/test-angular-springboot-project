package com.smbc.library.infrastructure.persistence;

import com.smbc.library.domain.model.Book;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.repository.BookRepository;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

// Not thread-safe on its own; only accessed inside UnitOfWork.
public class InMemoryBookRepository implements BookRepository {

    private final Map<BookTitle, Book> booksByTitle = new LinkedHashMap<>();

    @Override
    public Optional<Book> findByTitle(BookTitle title) {
        return Optional.ofNullable(booksByTitle.get(title));
    }

    @Override
    public List<Book> findAll() {
        return List.copyOf(booksByTitle.values());
    }

    @Override
    public void save(Book book) {
        booksByTitle.put(book.title(), book);
    }
}
