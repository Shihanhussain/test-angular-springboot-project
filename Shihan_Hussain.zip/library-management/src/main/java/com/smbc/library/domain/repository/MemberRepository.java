package com.smbc.library.domain.repository;

import com.smbc.library.domain.model.Member;
import com.smbc.library.domain.model.Username;

import java.util.Optional;

public interface MemberRepository {

    Optional<Member> findByUsername(Username username);

    void save(Member member);
}
