package com.smbc.library.domain.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

// Loans and wait lists live on Book. Member only holds hand-over notices until the next login.
public final class Member {

    private final Username username;
    private final List<BookTitle> pendingHandOverNotices = new ArrayList<>();

    private Member(Username username) {
        this.username = Objects.requireNonNull(username, "username");
    }

    public static Member register(Username username) {
        return new Member(username);
    }

    public Username username() {
        return username;
    }

    public boolean isAdmin() {
        return username.isAdmin();
    }

    public void notifyHandOver(BookTitle title) {
        pendingHandOverNotices.add(title);
    }

    public List<BookTitle> collectHandOverNotices() {
        List<BookTitle> notices = List.copyOf(pendingHandOverNotices);
        pendingHandOverNotices.clear();
        return notices;
    }
}
