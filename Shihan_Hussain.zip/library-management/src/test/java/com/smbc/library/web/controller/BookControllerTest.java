package com.smbc.library.web.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(BookController.class)
class BookControllerTest extends WebLayerTestSupport {

    @Test
    @DisplayName("lists the catalog in registration order with each book's status")
    void listsBooks() throws Exception {
        registerBooks("The Great Gatsby", "1984");
        lending.borrow(member("Bob"), "1984");

        mvc.perform(getAs(tokenFor("Alice"), "/api/books"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].title").value("The Great Gatsby"))
                .andExpect(jsonPath("$[0].status").value("AVAILABLE"))
                .andExpect(jsonPath("$[1].title").value("1984"))
                .andExpect(jsonPath("$[1].status").value("BORROWED"));
    }

    @Test
    @DisplayName("an empty catalog is an empty list")
    void listsEmptyCatalog() throws Exception {
        mvc.perform(getAs(tokenFor("Alice"), "/api/books"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    @Test
    @DisplayName("listing requires a session")
    void listingRequiresSession() throws Exception {
        mvc.perform(get("/api/books"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("auth.not-authenticated"));
    }

    @Test
    @DisplayName("the admin adds a book, which then appears in the catalog")
    void adminAddsBook() throws Exception {
        String admin = tokenFor("admin");

        mvc.perform(postTitleAs(admin, "/api/books", "  1984 "))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.message").value("Book \"1984\" has been added to the library."));
        mvc.perform(getAs(admin, "/api/books"))
                .andExpect(jsonPath("$[0].title").value("1984"));
    }

    @Test
    @DisplayName("a member who is not the admin is forbidden from adding books")
    void nonAdminIsForbidden() throws Exception {
        String alice = tokenFor("Alice");

        mvc.perform(postTitleAs(alice, "/api/books", "Dune"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("auth.admin-required"))
                .andExpect(jsonPath("$.message").value("Sorry, only admin can add books."));
        mvc.perform(getAs(alice, "/api/books"))
                .andExpect(jsonPath("$.length()").value(0));
    }

    @Test
    @DisplayName("a duplicate title, in any letter case, is a conflict")
    void duplicateIsConflict() throws Exception {
        registerBooks("The Great Gatsby");

        mvc.perform(postTitleAs(tokenFor("admin"), "/api/books", "the great gatsby"))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("book.already-registered"))
                .andExpect(jsonPath("$.message").value("Sorry, \"The Great Gatsby\" is already registered."));
    }

    @Test
    @DisplayName("a blank title is a validation error")
    void blankTitleIsRejected() throws Exception {
        mvc.perform(postTitleAs(tokenFor("admin"), "/api/books", "   "))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("validation.title.required"))
                .andExpect(jsonPath("$.message").value("Please enter a book title."));
    }
}
