package com.smbc.library.application.service;

import com.smbc.library.application.port.UnitOfWork;
import com.smbc.library.domain.model.Username;
import com.smbc.library.infrastructure.persistence.InMemoryBookRepository;
import com.smbc.library.infrastructure.persistence.InMemoryMemberRepository;
import com.smbc.library.infrastructure.session.InMemorySessionRegistry;
import com.smbc.library.infrastructure.transaction.ReadWriteLockUnitOfWork;

import java.time.Clock;
import java.time.Duration;

final class InMemoryLibrary {

    final InMemoryBookRepository books = new InMemoryBookRepository();
    final InMemoryMemberRepository members = new InMemoryMemberRepository();
    final InMemorySessionRegistry sessions = new InMemorySessionRegistry(Clock.systemUTC(), Duration.ofMinutes(30));
    final UnitOfWork unitOfWork = new ReadWriteLockUnitOfWork();

    final MemberStatusService status = new MemberStatusService(books, unitOfWork);
    final MembershipService membership = new MembershipService(members, sessions, status, unitOfWork);
    final CatalogService catalog = new CatalogService(books, unitOfWork);
    final LendingService lending = new LendingService(books, members, unitOfWork);
    final WaitlistService waitlist = new WaitlistService(books, unitOfWork);

    Username login(String name) {
        return membership.login(name).username();
    }

    void registerBooks(String... titles) {
        Username admin = login("admin");
        for (String title : titles) {
            catalog.addBook(admin, title);
        }
    }
}
