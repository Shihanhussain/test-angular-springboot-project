package com.smbc.library.web.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smbc.library.application.service.CatalogService;
import com.smbc.library.application.service.LendingService;
import com.smbc.library.application.service.MembershipService;
import com.smbc.library.application.service.WaitlistService;
import com.smbc.library.domain.model.Username;
import com.smbc.library.infrastructure.config.LibraryConfiguration;
import com.smbc.library.web.mapper.ResponseMapper;
import com.smbc.library.web.message.UserMessages;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

// Controllers run against the real services and in-memory storage; state is set up through the services
// and every test gets a fresh library.
@Import({LibraryConfiguration.class, ResponseMapper.class, UserMessages.class})
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
abstract class WebLayerTestSupport {

    private static final ObjectMapper JSON = new ObjectMapper();

    @Autowired
    MockMvc mvc;

    @Autowired
    MembershipService membership;

    @Autowired
    CatalogService catalog;

    @Autowired
    LendingService lending;

    @Autowired
    WaitlistService waitlist;

    String tokenFor(String name) {
        return membership.login(name).token().value();
    }

    Username member(String name) {
        return membership.login(name).username();
    }

    void registerBooks(String... titles) {
        Username admin = member("admin");
        for (String title : titles) {
            catalog.addBook(admin, title);
        }
    }

    static MockHttpServletRequestBuilder getAs(String token, String path) {
        return get(path).header(HttpHeaders.AUTHORIZATION, "Bearer " + token);
    }

    static MockHttpServletRequestBuilder postTitleAs(String token, String path, String title) throws Exception {
        return post(path)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(JSON.writeValueAsString(Map.of("title", title)));
    }
}
