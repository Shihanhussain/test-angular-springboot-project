package com.smbc.library.web.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import static org.hamcrest.Matchers.contains;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SessionController.class)
class SessionControllerTest extends WebLayerTestSupport {

    @Nested
    class Login {

        @Test
        @DisplayName("greets the member, reports hand-overs as typed notices and returns the session and status")
        void logsInMember() throws Exception {
            registerBooks("The Great Gatsby", "1984", "Dune");
            lending.borrow(member("Alice"), "1984");
            lending.borrow(member("Bob"), "The Great Gatsby");
            waitlist.join(member("Bob"), "1984");
            lending.borrow(member("Carol"), "Dune");
            waitlist.join(member("Alice"), "Dune");
            waitlist.join(member("Bob"), "Dune");
            lending.returnBook(member("Alice"), "1984");

            mvc.perform(login("{\"username\":\"bob\"}"))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.token").isString())
                    .andExpect(jsonPath("$.username").value("Bob"))
                    .andExpect(jsonPath("$.admin").value(false))
                    .andExpect(jsonPath("$.greeting").value("Hello, Bob!"))
                    .andExpect(jsonPath("$.notices.length()").value(1))
                    .andExpect(jsonPath("$.notices[0].type").value("HAND_OVER"))
                    .andExpect(jsonPath("$.notices[0].message").value("You got the book \"1984\" from your waitlist"))
                    .andExpect(jsonPath("$.status.borrowedBooks", contains("The Great Gatsby", "1984")))
                    .andExpect(jsonPath("$.status.waitlists[0].title").value("Dune"))
                    .andExpect(jsonPath("$.status.waitlists[0].position").value(2));
        }

        @Test
        @DisplayName("a hand-over is announced only on the next login")
        void handOverNoticeIsShownOnce() throws Exception {
            registerBooks("1984");
            lending.borrow(member("Alice"), "1984");
            waitlist.join(member("Bob"), "1984");
            lending.returnBook(member("Alice"), "1984");

            mvc.perform(login("{\"username\":\"Bob\"}")).andExpect(jsonPath("$.notices.length()").value(1));
            mvc.perform(login("{\"username\":\"Bob\"}")).andExpect(jsonPath("$.notices.length()").value(0));
        }

        @Test
        @DisplayName("tells the admin they can manage the library")
        void greetsAdmin() throws Exception {
            mvc.perform(login("{\"username\":\"admin\"}"))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.admin").value(true))
                    .andExpect(jsonPath("$.greeting").value("Hello, admin!"))
                    .andExpect(jsonPath("$.notices[0].type").value("ADMIN_ACCESS"))
                    .andExpect(jsonPath("$.notices[0].message").value("You have access to library management"));
        }

        @Test
        @DisplayName("turns a validation error into 400 with the limit in the message")
        void translatesDomainValidation() throws Exception {
            mvc.perform(login("{\"username\":\"" + "x".repeat(51) + "\"}"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.code").value("validation.username.too-long"))
                    .andExpect(jsonPath("$.message").value("Names can be at most 50 characters long."));
        }

        @Test
        @DisplayName("rejects a missing name")
        void rejectsMissingName() throws Exception {
            mvc.perform(login("{}"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.code").value("validation.username.required"));
        }

        @Test
        @DisplayName("rejects malformed JSON")
        void rejectsMalformedJson() throws Exception {
            mvc.perform(login("{\"username\":"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.code").value("request.malformed"));
        }

        @Test
        @DisplayName("rejects a body that is not JSON")
        void rejectsUnsupportedMediaType() throws Exception {
            mvc.perform(post("/api/sessions").contentType(MediaType.TEXT_PLAIN).content("Alice"))
                    .andExpect(status().isUnsupportedMediaType())
                    .andExpect(jsonPath("$.code").value("request.unsupported-media-type"));
        }

        @Test
        @DisplayName("rejects an unsupported HTTP method")
        void rejectsWrongMethod() throws Exception {
            mvc.perform(put("/api/sessions"))
                    .andExpect(status().isMethodNotAllowed())
                    .andExpect(jsonPath("$.code").value("request.method-not-allowed"));
        }

        private static MockHttpServletRequestBuilder login(String body) {
            return post("/api/sessions").contentType(MediaType.APPLICATION_JSON).content(body);
        }
    }

    @Nested
    class Logout {

        @Test
        @DisplayName("says goodbye and ends the session")
        void logsOut() throws Exception {
            String token = tokenFor("Alice");

            mvc.perform(logout(token))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.message").value("Goodbye, Alice!"));
            mvc.perform(logout(token)).andExpect(status().isUnauthorized());
        }

        @Test
        @DisplayName("requires a session")
        void requiresSession() throws Exception {
            mvc.perform(delete("/api/sessions/current"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.code").value("auth.not-authenticated"))
                    .andExpect(jsonPath("$.message").value("Please log in first."));
        }

        @Test
        @DisplayName("rejects credentials that are not a bearer token")
        void rejectsOtherSchemes() throws Exception {
            mvc.perform(delete("/api/sessions/current").header(HttpHeaders.AUTHORIZATION, "Basic YWxpY2U6"))
                    .andExpect(status().isUnauthorized());
            mvc.perform(delete("/api/sessions/current").header(HttpHeaders.AUTHORIZATION, "Bearer   "))
                    .andExpect(status().isUnauthorized());
        }

        @Test
        @DisplayName("rejects an unknown session")
        void rejectsUnknownSession() throws Exception {
            mvc.perform(logout("not-a-real-session")).andExpect(status().isUnauthorized());
        }

        private static MockHttpServletRequestBuilder logout(String token) {
            return delete("/api/sessions/current").header(HttpHeaders.AUTHORIZATION, "Bearer " + token);
        }
    }
}
