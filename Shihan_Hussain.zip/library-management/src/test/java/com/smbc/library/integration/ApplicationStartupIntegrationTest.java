package com.smbc.library.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class ApplicationStartupIntegrationTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper json;

    @Test
    @DisplayName("a new application context starts with an empty library")
    void startsWithEmptyLibrary() throws Exception {
        LibraryApiClient client = new LibraryApiClient(mvc, json);

        LibraryApiClient.Response login = client.login("admin");
        assertThat(login.borrowedBooks()).isEmpty();
        assertThat(client.list().catalog()).isEmpty();
    }

    @Test
    @DisplayName("reports healthy once started; the Playwright tests wait for this")
    void reportsHealth() throws Exception {
        mvc.perform(get("/actuator/health"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"));
    }

    @Test
    @DisplayName("serves the single-page app for any client-side route, including nested ones")
    void forwardsClientRoutesToTheApp() throws Exception {
        for (String route : new String[]{"/login", "/library", "/some/future/route"}) {
            mvc.perform(get(route)).andExpect(forwardedUrl("/index.html"));
        }
    }

    @Test
    @DisplayName("does not treat missing files as app routes")
    void doesNotForwardFileRequests() throws Exception {
        mvc.perform(get("/missing-script.js")).andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("a session cannot be logged out twice")
    void logoutTwice() throws Exception {
        LibraryApiClient client = new LibraryApiClient(mvc, json);
        client.login("Alice");

        client.logout().hasStatus(200);
        assertThat(client.logout().hasStatus(401).message()).isEqualTo("Please log in first.");
    }

    @Test
    @DisplayName("an unknown API route returns the standard error body")
    void unknownRoute() throws Exception {
        mvc.perform(get("/api/does-not-exist"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("request.not-found"));
    }
}
