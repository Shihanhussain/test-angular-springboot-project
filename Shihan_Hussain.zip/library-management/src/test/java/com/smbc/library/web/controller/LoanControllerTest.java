package com.smbc.library.web.controller;

import com.smbc.library.application.result.BookStatus;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(LoanController.class)
class LoanControllerTest extends WebLayerTestSupport {

    @Test
    @DisplayName("borrowing confirms with the registered spelling of the title")
    void borrows() throws Exception {
        registerBooks("The Great Gatsby");

        mvc.perform(postTitleAs(tokenFor("Alice"), "/api/loans", "the great gatsby"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.message").value("You borrowed \"The Great Gatsby\"."));
    }

    @Test
    @DisplayName("an unregistered title cannot be borrowed")
    void borrowUnknownBook() throws Exception {
        mvc.perform(postTitleAs(tokenFor("Alice"), "/api/loans", "1985"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("book.not-found"))
                .andExpect(jsonPath("$.message").value("Sorry, \"1985\" is not registered."));
    }

    @Test
    @DisplayName("a book held by someone else cannot be borrowed")
    void borrowUnavailableBook() throws Exception {
        registerBooks("1984");
        lending.borrow(member("Bob"), "1984");

        mvc.perform(postTitleAs(tokenFor("Alice"), "/api/loans", "1984"))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("book.not-available"))
                .andExpect(jsonPath("$.message").value("Sorry, \"1984\" is currently not available"));
    }

    @Test
    @DisplayName("borrowing a book you already hold is a conflict")
    void borrowTwice() throws Exception {
        registerBooks("1984");
        String alice = tokenFor("Alice");
        mvc.perform(postTitleAs(alice, "/api/loans", "1984")).andExpect(status().isCreated());

        mvc.perform(postTitleAs(alice, "/api/loans", "1984"))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("book.already-borrowed-by-you"))
                .andExpect(jsonPath("$.message").value("You have already borrowed \"1984\"."));
    }

    @Test
    @DisplayName("borrowing requires a session")
    void borrowRequiresSession() throws Exception {
        registerBooks("1984");

        mvc.perform(postTitleAs("unknown", "/api/loans", "1984")).andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("returning confirms and makes the book available again")
    void returnsBook() throws Exception {
        registerBooks("1984");
        String alice = tokenFor("Alice");
        mvc.perform(postTitleAs(alice, "/api/loans", "1984")).andExpect(status().isCreated());

        mvc.perform(postTitleAs(alice, "/api/returns", "1984"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("You returned \"1984\"."));
        assertThat(catalog.listBooks()).singleElement()
                .satisfies(book -> assertThat(book.status()).isEqualTo(BookStatus.AVAILABLE));
    }

    @Test
    @DisplayName("returning a book you did not borrow is a conflict")
    void returnNotBorrowed() throws Exception {
        registerBooks("The Great Gatsby");
        lending.borrow(member("Bob"), "The Great Gatsby");

        mvc.perform(postTitleAs(tokenFor("Carol"), "/api/returns", "The Great Gatsby"))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("book.not-borrowed-by-you"))
                .andExpect(jsonPath("$.message").value("Sorry, you didn't borrow \"The Great Gatsby\""));
    }
}
