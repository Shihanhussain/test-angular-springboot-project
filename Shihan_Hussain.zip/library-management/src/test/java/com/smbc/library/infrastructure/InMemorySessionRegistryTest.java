package com.smbc.library.infrastructure;

import com.smbc.library.application.port.SessionToken;
import com.smbc.library.domain.model.Username;
import com.smbc.library.infrastructure.session.InMemorySessionRegistry;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

class InMemorySessionRegistryTest {

    private static final Duration IDLE_TIMEOUT = Duration.ofMinutes(30);
    private static final Username ALICE = Username.of("Alice");

    private final AdjustableClock clock = new AdjustableClock(Instant.parse("2026-01-01T09:00:00Z"));
    private final InMemorySessionRegistry registry = new InMemorySessionRegistry(clock, IDLE_TIMEOUT);

    @Test
    @DisplayName("an opened session resolves to its member until it is closed")
    void opensAndClosesSessions() {
        SessionToken token = registry.open(ALICE);

        assertThat(registry.find(token)).contains(ALICE);
        assertThat(registry.close(token)).contains(ALICE);
        assertThat(registry.find(token)).isEmpty();
        assertThat(registry.close(token)).isEmpty();
    }

    @Test
    @DisplayName("tokens are unguessable and unique")
    void tokensAreUnique() {
        Set<SessionToken> tokens = new HashSet<>();
        for (int i = 0; i < 1_000; i++) {
            tokens.add(registry.open(ALICE));
        }

        assertThat(tokens).hasSize(1_000)
                .allSatisfy(token -> assertThat(token.value()).hasSizeGreaterThanOrEqualTo(40));
    }

    @Test
    @DisplayName("an unknown token resolves to nobody")
    void unknownToken() {
        assertThat(registry.find(new SessionToken("nope"))).isEmpty();
    }

    @Test
    @DisplayName("a session left unused for the idle timeout expires")
    void idleSessionExpires() {
        SessionToken token = registry.open(ALICE);

        clock.advance(IDLE_TIMEOUT.minusSeconds(1));
        assertThat(registry.find(token)).contains(ALICE);

        clock.advance(IDLE_TIMEOUT);
        assertThat(registry.find(token)).isEmpty();
        assertThat(registry.close(token)).isEmpty();
    }

    @Test
    @DisplayName("using a session keeps it alive")
    void useExtendsSession() {
        SessionToken token = registry.open(ALICE);

        for (int i = 0; i < 4; i++) {
            clock.advance(Duration.ofMinutes(20));
            assertThat(registry.find(token)).contains(ALICE);
        }
    }

    @Test
    @DisplayName("an expired session cannot be used to sign out")
    void expiredSessionCannotBeClosed() {
        SessionToken token = registry.open(ALICE);

        clock.advance(IDLE_TIMEOUT);

        assertThat(registry.close(token)).isEmpty();
    }

    @Test
    @DisplayName("the idle timeout must be positive")
    void rejectsNonPositiveTimeout() {
        assertThatIllegalArgumentException().isThrownBy(() -> new InMemorySessionRegistry(clock, Duration.ZERO));
    }

    private static final class AdjustableClock extends Clock {

        private Instant now;

        AdjustableClock(Instant start) {
            this.now = start;
        }

        void advance(Duration duration) {
            now = now.plus(duration);
        }

        @Override
        public ZoneId getZone() {
            return ZoneOffset.UTC;
        }

        @Override
        public Clock withZone(ZoneId zone) {
            return this;
        }

        @Override
        public Instant instant() {
            return now;
        }
    }
}
