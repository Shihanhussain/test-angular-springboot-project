package com.smbc.library.application.service;

import com.smbc.library.domain.exception.BookNotAvailableException;
import com.smbc.library.domain.model.Username;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Function;
import java.util.stream.IntStream;

import static org.assertj.core.api.Assertions.assertThat;

class ConcurrencyTest {

    private static final int MEMBERS = 16;

    private final InMemoryLibrary library = new InMemoryLibrary();

    @RepeatedTest(5)
    @DisplayName("when many members borrow the same copy at the same moment, exactly one succeeds")
    void onlyOneConcurrentBorrowerWins() throws Exception {
        library.registerBooks("1984");

        List<Boolean> outcomes = runAtOnce(registerMembers(), member -> () -> {
            try {
                library.lending.borrow(member, "1984");
                return true;
            } catch (BookNotAvailableException expected) {
                return false;
            }
        });

        assertThat(outcomes).containsOnlyOnce(true);
    }

    @RepeatedTest(5)
    @DisplayName("members joining a wait list at the same moment get distinct positions 1..n")
    void concurrentWaitlistJoinsGetDistinctPositions() throws Exception {
        library.registerBooks("1984");
        library.lending.borrow(library.login("holder"), "1984");

        List<Integer> positions = runAtOnce(registerMembers(),
                member -> () -> library.waitlist.join(member, "1984").position());

        assertThat(positions).containsExactlyInAnyOrderElementsOf(IntStream.rangeClosed(1, MEMBERS).boxed().toList());
    }

    private List<Username> registerMembers() {
        return IntStream.range(0, MEMBERS).mapToObj(i -> library.login("member-" + i)).toList();
    }

    private static <T> List<T> runAtOnce(List<Username> members, Function<Username, Callable<T>> work)
            throws Exception {
        CountDownLatch start = new CountDownLatch(1);
        List<Future<T>> futures = new ArrayList<>();
        try (ExecutorService executor = Executors.newFixedThreadPool(members.size())) {
            for (Username member : members) {
                Callable<T> task = work.apply(member);
                futures.add(executor.submit(() -> {
                    start.await();
                    return task.call();
                }));
            }
            start.countDown();
            List<T> results = new ArrayList<>();
            for (Future<T> future : futures) {
                results.add(future.get());
            }
            return results;
        }
    }
}