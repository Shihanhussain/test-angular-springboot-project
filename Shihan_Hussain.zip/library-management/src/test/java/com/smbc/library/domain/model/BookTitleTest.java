package com.smbc.library.domain.model;

import com.smbc.library.domain.exception.InvalidValueException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class BookTitleTest {

    @Test
    @DisplayName("normalises whitespace and keeps the original spelling")
    void normalisesWhitespace() {
        assertThat(BookTitle.of("  The   Great Gatsby ").display()).isEqualTo("The Great Gatsby");
    }

    @Test
    @DisplayName("treats titles that differ only in case as the same book")
    void comparesIgnoringCase() {
        assertThat(BookTitle.of("The Great Gatsby"))
                .isEqualTo(BookTitle.of("the great GATSBY"))
                .hasSameHashCodeAs(BookTitle.of("THE GREAT GATSBY"))
                .hasToString("The Great Gatsby");
    }

    @Test
    @DisplayName("compares accented titles ignoring case and keeps punctuation")
    void handlesAccentsAndPunctuation() {
        assertThat(BookTitle.of("Les Misérables")).isEqualTo(BookTitle.of("LES MISÉRABLES"));
        assertThat(BookTitle.of("Ender's Game: \"Special\" Edition").display())
                .isEqualTo("Ender's Game: \"Special\" Edition");
    }

    @Test
    @DisplayName("measures the length after collapsing whitespace")
    void measuresNormalisedLength() {
        assertThat(BookTitle.of("b".repeat(100) + "     " + "b".repeat(99)).display()).hasSize(200);
    }

    @Test
    @DisplayName("distinguishes different titles")
    void differentTitles() {
        assertThat(BookTitle.of("1984")).isNotEqualTo(BookTitle.of("1985")).isNotEqualTo("1984");
        assertThat(BookTitle.of("1984").hashCode()).isNotEqualTo(BookTitle.of("1985").hashCode());
    }

    @ParameterizedTest
    @NullSource
    @ValueSource(strings = {"", "  "})
    @DisplayName("rejects a missing or blank title")
    void rejectsBlank(String raw) {
        assertThatThrownBy(() -> BookTitle.of(raw))
                .isInstanceOfSatisfying(InvalidValueException.class,
                        error -> assertThat(error.messageKey()).isEqualTo("validation.title.required"));
    }

    @Test
    @DisplayName("accepts exactly 200 characters and rejects 201")
    void enforcesMaximumLength() {
        assertThat(BookTitle.of("b".repeat(200)).display()).hasSize(200);
        assertThatThrownBy(() -> BookTitle.of("b".repeat(201)))
                .isInstanceOfSatisfying(InvalidValueException.class, error -> {
                    assertThat(error.messageKey()).isEqualTo("validation.title.too-long");
                    assertThat(error.messageArguments()).containsExactly(BookTitle.MAX_LENGTH);
                });
    }
}
