package com.smbc.library.domain.model;

import com.smbc.library.domain.exception.AlreadyOnWaitlistException;
import com.smbc.library.domain.exception.BookAlreadyBorrowedByMemberException;
import com.smbc.library.domain.exception.BookAvailableForBorrowingException;
import com.smbc.library.domain.exception.BookNotAvailableException;
import com.smbc.library.domain.exception.BookNotBorrowedByMemberException;
import com.smbc.library.domain.exception.ErrorCategory;
import com.smbc.library.domain.exception.LibraryException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class BookTest {

    private static final Username ALICE = Username.of("Alice");
    private static final Username BOB = Username.of("Bob");
    private static final Username CAROL = Username.of("Carol");

    private final Book book = Book.register(BookTitle.of("1984"));

    @Test
    @DisplayName("a newly registered book is available and nobody is waiting")
    void newBookIsAvailable() {
        assertThat(book.title()).isEqualTo(BookTitle.of("1984"));
        assertThat(book.isAvailable()).isTrue();
        assertThat(book.isBorrowedBy(ALICE)).isFalse();
        assertThat(book.waitlistPositionOf(ALICE)).isEmpty();
    }

    @Test
    @DisplayName("requires a title")
    void requiresTitle() {
        assertThatNullPointerException().isThrownBy(() -> Book.register(null));
    }

    @Nested
    class Borrowing {

        @Test
        @DisplayName("an available book can be borrowed and is then no longer available")
        void borrowsAvailableBook() {
            book.borrowBy(ALICE);

            assertThat(book.isAvailable()).isFalse();
            assertThat(book.isBorrowedBy(Username.of("alice"))).isTrue();
            assertThat(book.isBorrowedBy(BOB)).isFalse();
        }

        @Test
        @DisplayName("a book held by someone else cannot be borrowed")
        void rejectsBorrowingUnavailableBook() {
            book.borrowBy(ALICE);

            assertConflict(() -> book.borrowBy(BOB), BookNotAvailableException.class, "book.not-available");
            assertThat(book.isBorrowedBy(ALICE)).isTrue();
        }

        @Test
        @DisplayName("borrowing a book you already hold is rejected")
        void rejectsBorrowingTwice() {
            book.borrowBy(ALICE);

            assertConflict(() -> book.borrowBy(ALICE), BookAlreadyBorrowedByMemberException.class,
                    "book.already-borrowed-by-you");
        }
    }

    @Nested
    class Returning {

        @Test
        @DisplayName("returning with nobody waiting makes the book available again")
        void returnMakesBookAvailable() {
            book.borrowBy(ALICE);

            assertThat(book.returnBy(ALICE)).isEmpty();
            assertThat(book.isAvailable()).isTrue();
        }

        @Test
        @DisplayName("only the borrower can return a book")
        void onlyBorrowerCanReturn() {
            book.borrowBy(ALICE);

            assertConflict(() -> book.returnBy(BOB), BookNotBorrowedByMemberException.class,
                    "book.not-borrowed-by-you");
            assertThat(book.isBorrowedBy(ALICE)).isTrue();
        }

        @Test
        @DisplayName("an available book cannot be returned")
        void cannotReturnAvailableBook() {
            assertConflict(() -> book.returnBy(ALICE), BookNotBorrowedByMemberException.class,
                    "book.not-borrowed-by-you");
        }

        @Test
        @DisplayName("a returned book is handed straight to the first waiting member")
        void handsOverToFirstWaitingMember() {
            book.borrowBy(ALICE);
            book.addToWaitlist(BOB);
            book.addToWaitlist(CAROL);

            assertThat(book.returnBy(ALICE)).contains(BOB);

            assertThat(book.isAvailable()).isFalse();
            assertThat(book.isBorrowedBy(BOB)).isTrue();
            assertThat(book.waitlistPositionOf(BOB)).isEmpty();
            assertThat(book.waitlistPositionOf(CAROL)).hasValue(1);
        }

        @Test
        @DisplayName("the hand-over continues down the queue until it is empty")
        void handOverChain() {
            book.borrowBy(ALICE);
            book.addToWaitlist(BOB);
            book.addToWaitlist(CAROL);

            book.returnBy(ALICE);
            assertThat(book.returnBy(BOB)).contains(CAROL);
            assertThat(book.returnBy(CAROL)).isEmpty();
            assertThat(book.isAvailable()).isTrue();
        }
    }

    @Nested
    class Waitlisting {

        @Test
        @DisplayName("members join the wait list of a borrowed book in arrival order")
        void joinsWaitlist() {
            book.borrowBy(ALICE);

            assertThat(book.addToWaitlist(BOB)).isEqualTo(1);
            assertThat(book.addToWaitlist(CAROL)).isEqualTo(2);
            assertThat(book.waitlistPositionOf(CAROL)).hasValue(2);
        }

        @Test
        @DisplayName("an available book cannot be wait-listed")
        void rejectsWaitlistForAvailableBook() {
            assertConflict(() -> book.addToWaitlist(BOB), BookAvailableForBorrowingException.class,
                    "waitlist.book-available");
        }

        @Test
        @DisplayName("the borrower cannot join the wait list of their own book")
        void borrowerCannotWaitlist() {
            book.borrowBy(ALICE);

            assertConflict(() -> book.addToWaitlist(ALICE), BookAlreadyBorrowedByMemberException.class,
                    "book.already-borrowed-by-you");
        }

        @Test
        @DisplayName("joining the same wait list twice is rejected with the current position")
        void rejectsDuplicateWaitlistEntry() {
            book.borrowBy(ALICE);
            book.addToWaitlist(BOB);
            book.addToWaitlist(CAROL);

            assertThatThrownBy(() -> book.addToWaitlist(Username.of("carol")))
                    .isInstanceOfSatisfying(AlreadyOnWaitlistException.class, error -> {
                        assertThat(error.messageKey()).isEqualTo("waitlist.already-joined");
                        assertThat(error.messageArguments()).containsExactly("1984", 2);
                    });
        }
    }

    private static void assertConflict(Runnable action, Class<? extends LibraryException> type, String key) {
        assertThatThrownBy(action::run)
                .isInstanceOfSatisfying(type, error -> {
                    assertThat(error.category()).isEqualTo(ErrorCategory.CONFLICT);
                    assertThat(error.messageKey()).isEqualTo(key);
                    assertThat(error.messageArguments()).containsExactly("1984");
                });
    }
}
