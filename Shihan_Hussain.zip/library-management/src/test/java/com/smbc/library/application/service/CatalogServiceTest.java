package com.smbc.library.application.service;

import com.smbc.library.application.result.BookStatus;
import com.smbc.library.application.result.BookSummary;
import com.smbc.library.application.exception.AdminPrivilegeRequiredException;
import com.smbc.library.domain.exception.BookAlreadyRegisteredException;
import com.smbc.library.domain.exception.ErrorCategory;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Username;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class CatalogServiceTest {

    private final InMemoryLibrary library = new InMemoryLibrary();
    private final CatalogService catalog = library.catalog;
    private final Username admin = library.login("admin");

    @Test
    @DisplayName("a new library has no books")
    void startsEmpty() {
        assertThat(catalog.listBooks()).isEmpty();
    }

    @Test
    @DisplayName("the admin adds books, which are listed in registration order as available")
    void adminAddsBooks() {
        assertThat(catalog.addBook(admin, " The  Great Gatsby ")).isEqualTo(BookTitle.of("The Great Gatsby"));
        catalog.addBook(admin, "1984");

        assertThat(catalog.listBooks()).containsExactly(
                new BookSummary(BookTitle.of("The Great Gatsby"), BookStatus.AVAILABLE),
                new BookSummary(BookTitle.of("1984"), BookStatus.AVAILABLE));
    }

    @Test
    @DisplayName("only the admin can add books")
    void nonAdminCannotAddBooks() {
        Username alice = library.login("Alice");

        assertThatThrownBy(() -> catalog.addBook(alice, "Dune"))
                .isInstanceOfSatisfying(AdminPrivilegeRequiredException.class, error -> {
                    assertThat(error.category()).isEqualTo(ErrorCategory.FORBIDDEN);
                    assertThat(error.messageKey()).isEqualTo("auth.admin-required");
                });
        assertThat(catalog.listBooks()).isEmpty();
    }

    @Test
    @DisplayName("a title is registered once, ignoring case, and the error names the registered title")
    void rejectsDuplicateTitles() {
        catalog.addBook(admin, "1984");
        catalog.addBook(admin, "Dune");

        assertThatThrownBy(() -> catalog.addBook(admin, "dUNE"))
                .isInstanceOfSatisfying(BookAlreadyRegisteredException.class, error -> {
                    assertThat(error.category()).isEqualTo(ErrorCategory.CONFLICT);
                    assertThat(error.messageKey()).isEqualTo("book.already-registered");
                    assertThat(error.messageArguments()).containsExactly("Dune");
                });
        assertThat(catalog.listBooks()).hasSize(2);
    }

    @Test
    @DisplayName("a borrowed book is still listed, marked as borrowed")
    void listsBorrowedBooks() {
        catalog.addBook(admin, "1984");
        library.lending.borrow(library.login("Alice"), "1984");

        assertThat(catalog.listBooks())
                .containsExactly(new BookSummary(BookTitle.of("1984"), BookStatus.BORROWED));
    }
}
