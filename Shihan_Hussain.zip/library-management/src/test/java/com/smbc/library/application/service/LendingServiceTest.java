package com.smbc.library.application.service;

import com.smbc.library.application.result.BookStatus;
import com.smbc.library.domain.exception.BookAlreadyBorrowedByMemberException;
import com.smbc.library.domain.exception.BookNotAvailableException;
import com.smbc.library.domain.exception.BookNotBorrowedByMemberException;
import com.smbc.library.domain.exception.BookNotFoundException;
import com.smbc.library.domain.exception.ErrorCategory;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Username;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class LendingServiceTest {

    private final InMemoryLibrary library = new InMemoryLibrary();
    private final LendingService lending = library.lending;
    private Username alice;
    private Username bob;
    private Username carol;

    @BeforeEach
    void setUp() {
        library.registerBooks("The Great Gatsby", "1984");
        alice = library.login("Alice");
        bob = library.login("Bob");
        carol = library.login("Carol");
    }

    @Test
    @DisplayName("borrowing returns the registered spelling of the title")
    void borrowReturnsCanonicalTitle() {
        assertThat(lending.borrow(alice, "the great gatsby").display()).isEqualTo("The Great Gatsby");
        assertThat(library.status.statusOf(alice).borrowedBooks())
                .containsExactly(BookTitle.of("The Great Gatsby"));
    }

    @Test
    @DisplayName("an unregistered title cannot be borrowed")
    void rejectsUnknownBook() {
        assertThatThrownBy(() -> lending.borrow(alice, "1985"))
                .isInstanceOfSatisfying(BookNotFoundException.class, error -> {
                    assertThat(error.category()).isEqualTo(ErrorCategory.NOT_FOUND);
                    assertThat(error.messageKey()).isEqualTo("book.not-found");
                    assertThat(error.messageArguments()).containsExactly("1985");
                });
    }

    @Test
    @DisplayName("a book held by someone else cannot be borrowed")
    void rejectsUnavailableBook() {
        lending.borrow(alice, "1984");

        assertThatThrownBy(() -> lending.borrow(bob, "1984")).isInstanceOf(BookNotAvailableException.class);
    }

    @Test
    @DisplayName("a member cannot borrow the same book twice")
    void rejectsBorrowingTwice() {
        lending.borrow(alice, "1984");

        assertThatThrownBy(() -> lending.borrow(alice, "1984"))
                .isInstanceOf(BookAlreadyBorrowedByMemberException.class);
    }

    @Test
    @DisplayName("returning a book with nobody waiting makes it available")
    void returnMakesBookAvailable() {
        lending.borrow(alice, "1984");

        assertThat(lending.returnBook(alice, "1984")).isEqualTo(BookTitle.of("1984"));
        assertThat(library.status.statusOf(alice).borrowedBooks()).isEmpty();
        assertThat(library.membership.login("Alice").handOverNotices()).isEmpty();
        assertThat(library.catalog.listBooks())
                .filteredOn(book -> book.title().equals(BookTitle.of("1984")))
                .singleElement().satisfies(book -> assertThat(book.status()).isEqualTo(BookStatus.AVAILABLE));
        assertThat(lending.borrow(bob, "1984")).isEqualTo(BookTitle.of("1984"));
    }

    @Test
    @DisplayName("a member cannot return a book they did not borrow")
    void rejectsReturnByNonBorrower() {
        lending.borrow(bob, "The Great Gatsby");

        assertThatThrownBy(() -> lending.returnBook(carol, "The Great Gatsby"))
                .isInstanceOfSatisfying(BookNotBorrowedByMemberException.class,
                        error -> assertThat(error.messageArguments()).containsExactly("The Great Gatsby"));
    }

    @Test
    @DisplayName("an unregistered title cannot be returned")
    void rejectsReturnOfUnknownBook() {
        assertThatThrownBy(() -> lending.returnBook(alice, "1985")).isInstanceOf(BookNotFoundException.class);
    }

    @Test
    @DisplayName("a returned book goes to the first waiting member, who is notified and the queue moves up")
    void returnHandsOverToFirstWaitingMember() {
        lending.borrow(alice, "1984");
        library.waitlist.join(bob, "1984");
        library.waitlist.join(carol, "1984");

        lending.returnBook(alice, "1984");

        assertThat(library.status.statusOf(bob).borrowedBooks()).containsExactly(BookTitle.of("1984"));
        assertThat(library.status.statusOf(bob).waitlists()).isEmpty();
        assertThat(library.status.statusOf(carol).waitlists())
                .singleElement().satisfies(entry -> assertThat(entry.position()).isEqualTo(1));
        assertThat(library.membership.login("Bob").handOverNotices()).containsExactly(BookTitle.of("1984"));
        assertThat(library.membership.login("Carol").handOverNotices()).isEmpty();
    }
}
