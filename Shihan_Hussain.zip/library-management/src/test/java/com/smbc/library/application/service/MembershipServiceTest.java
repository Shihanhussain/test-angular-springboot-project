package com.smbc.library.application.service;

import com.smbc.library.application.exception.NotAuthenticatedException;
import com.smbc.library.application.port.SessionToken;
import com.smbc.library.application.result.LoginResult;
import com.smbc.library.domain.exception.ErrorCategory;
import com.smbc.library.domain.exception.InvalidValueException;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Username;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MembershipServiceTest {

    private final InMemoryLibrary library = new InMemoryLibrary();
    private final MembershipService membership = library.membership;

    @Test
    @DisplayName("the first login registers the member and opens a session")
    void firstLoginRegistersMember() {
        LoginResult result = membership.login("Alice");

        assertThat(result.username().display()).isEqualTo("Alice");
        assertThat(result.admin()).isFalse();
        assertThat(result.handOverNotices()).isEmpty();
        assertThat(result.status().borrowedBooks()).isEmpty();
        assertThat(membership.authenticate(result.token())).isEqualTo(Username.of("Alice"));
        assertThat(library.members.findByUsername(Username.of("alice"))).isPresent();
    }

    @Test
    @DisplayName("a later login reuses the account and keeps the first spelling")
    void laterLoginReusesAccount() {
        membership.login("Alice");

        LoginResult again = membership.login("  ALICE ");

        assertThat(again.username().display()).isEqualTo("Alice");
    }

    @Test
    @DisplayName("admin is recognised at login in any case")
    void recognisesAdmin() {
        assertThat(membership.login("Admin").admin()).isTrue();
    }

    @Test
    @DisplayName("every login gets its own session")
    void eachLoginGetsOwnSession() {
        SessionToken first = membership.login("Alice").token();
        SessionToken second = membership.login("Alice").token();

        assertThat(first).isNotEqualTo(second);
        assertThat(membership.authenticate(first)).isEqualTo(membership.authenticate(second));
    }

    @Test
    @DisplayName("an invalid name is rejected before anything is registered")
    void rejectsInvalidName() {
        assertThatThrownBy(() -> membership.login("   ")).isInstanceOf(InvalidValueException.class);
    }

    @Test
    @DisplayName("a pending hand-over is announced at the next login only")
    void deliversHandOverNoticeOnce() {
        library.registerBooks("1984");
        Username alice = library.login("Alice");
        Username bob = library.login("Bob");
        library.lending.borrow(alice, "1984");
        library.waitlist.join(bob, "1984");
        library.lending.returnBook(alice, "1984");

        LoginResult bobsNextLogin = membership.login("Bob");

        assertThat(bobsNextLogin.handOverNotices()).containsExactly(BookTitle.of("1984"));
        assertThat(bobsNextLogin.status().borrowedBooks()).containsExactly(BookTitle.of("1984"));
        assertThat(membership.login("Bob").handOverNotices()).isEmpty();
    }

    @Test
    @DisplayName("a session cannot be logged out twice")
    void logoutTwiceIsRejected() {
        SessionToken token = membership.login("Alice").token();
        membership.logout(token);

        assertThatThrownBy(() -> membership.logout(token)).isInstanceOf(NotAuthenticatedException.class);
    }

    @Test
    @DisplayName("logout ends the session and returns who logged out")
    void logoutEndsSession() {
        SessionToken token = membership.login("Alice").token();

        assertThat(membership.logout(token).display()).isEqualTo("Alice");
        assertThatThrownBy(() -> membership.authenticate(token))
                .isInstanceOfSatisfying(NotAuthenticatedException.class, error -> {
                    assertThat(error.category()).isEqualTo(ErrorCategory.UNAUTHENTICATED);
                    assertThat(error.messageKey()).isEqualTo("auth.not-authenticated");
                });
    }

    @Test
    @DisplayName("logout with an unknown session is rejected")
    void logoutRequiresSession() {
        assertThatThrownBy(() -> membership.logout(new SessionToken("unknown")))
                .isInstanceOf(NotAuthenticatedException.class);
    }

    @Test
    @DisplayName("logging out one session keeps the member's other sessions")
    void logoutIsPerSession() {
        SessionToken tab1 = membership.login("Alice").token();
        SessionToken tab2 = membership.login("Alice").token();

        membership.logout(tab1);

        assertThat(membership.authenticate(tab2).display()).isEqualTo("Alice");
    }
}
