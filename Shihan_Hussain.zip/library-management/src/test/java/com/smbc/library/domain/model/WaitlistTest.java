package com.smbc.library.domain.model;

import com.smbc.library.domain.exception.AlreadyOnWaitlistException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class WaitlistTest {

    private static final Username ALICE = Username.of("Alice");
    private static final Username BOB = Username.of("Bob");
    private static final Username CAROL = Username.of("Carol");

    private final Waitlist waitlist = new Waitlist(BookTitle.of("1984"));

    @Test
    @DisplayName("a new wait list is empty")
    void startsEmpty() {
        assertThat(waitlist.poll()).isEmpty();
        assertThat(waitlist.positionOf(ALICE)).isEmpty();
    }

    @Test
    @DisplayName("positions start at 1 and follow arrival order")
    void assignsPositionsInArrivalOrder() {
        assertThat(waitlist.add(ALICE)).isEqualTo(1);
        assertThat(waitlist.add(BOB)).isEqualTo(2);

        assertThat(waitlist.positionOf(Username.of("alice"))).hasValue(1);
        assertThat(waitlist.positionOf(BOB)).hasValue(2);
        assertThat(waitlist.positionOf(CAROL)).isEmpty();
    }

    @Test
    @DisplayName("serves members first-in, first-out and moves everyone up")
    void isFirstInFirstOut() {
        waitlist.add(ALICE);
        waitlist.add(BOB);
        waitlist.add(CAROL);

        assertThat(waitlist.poll()).contains(ALICE);
        assertThat(waitlist.positionOf(BOB)).hasValue(1);
        assertThat(waitlist.positionOf(CAROL)).hasValue(2);
        assertThat(waitlist.poll()).contains(BOB);
        assertThat(waitlist.poll()).contains(CAROL);
        assertThat(waitlist.poll()).isEmpty();
    }

    @Test
    @DisplayName("a member cannot queue twice and is told their current position")
    void rejectsDuplicates() {
        waitlist.add(BOB);
        waitlist.add(ALICE);

        assertThatThrownBy(() -> waitlist.add(Username.of("alice")))
                .isInstanceOfSatisfying(AlreadyOnWaitlistException.class,
                        error -> assertThat(error.messageArguments()).containsExactly("1984", 2));
        assertThat(waitlist.add(CAROL)).isEqualTo(3);
    }
}
