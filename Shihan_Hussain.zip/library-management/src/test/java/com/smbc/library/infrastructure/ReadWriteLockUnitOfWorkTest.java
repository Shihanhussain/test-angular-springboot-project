package com.smbc.library.infrastructure;

import com.smbc.library.infrastructure.transaction.ReadWriteLockUnitOfWork;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

class ReadWriteLockUnitOfWorkTest {

    private final ReadWriteLockUnitOfWork unitOfWork = new ReadWriteLockUnitOfWork();

    @Test
    @DisplayName("returns the result of the work")
    void returnsResult() {
        assertThat(unitOfWork.read(() -> "read")).isEqualTo("read");
        assertThat(unitOfWork.write(() -> "write")).isEqualTo("write");
    }

    @Test
    @DisplayName("releases the lock when the work fails, so other threads can continue")
    void releasesLockOnFailure() throws Exception {
        assertThatIllegalArgumentException().isThrownBy(() -> unitOfWork.write(() -> {
            throw new IllegalArgumentException("boom");
        }));

        String fromOtherThread = CompletableFuture.supplyAsync(() -> unitOfWork.write(() -> "free"))
                .get(2, TimeUnit.SECONDS);
        assertThat(fromOtherThread).isEqualTo("free");
    }
}
