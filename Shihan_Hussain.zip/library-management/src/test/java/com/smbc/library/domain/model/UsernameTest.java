package com.smbc.library.domain.model;

import com.smbc.library.domain.exception.ErrorCategory;
import com.smbc.library.domain.exception.InvalidValueException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class UsernameTest {

    @Test
    @DisplayName("trims surrounding whitespace and collapses inner whitespace")
    void normalisesWhitespace() {
        assertThat(Username.of("  Mary   Jane \t").display()).isEqualTo("Mary Jane");
    }

    @Test
    @DisplayName("is equal to the same name in a different case")
    void comparesIgnoringCase() {
        assertThat(Username.of("Alice")).isEqualTo(Username.of("aLICE"))
                .hasSameHashCodeAs(Username.of("ALICE"));
    }

    @Test
    @DisplayName("keeps the spelling it was created with for display")
    void keepsOriginalSpelling() {
        assertThat(Username.of("aLiCe").display()).isEqualTo("aLiCe");
        assertThat(Username.of("aLiCe")).hasToString("aLiCe");
    }

    @Test
    @DisplayName("is different from another name and hashes differently")
    void differentNamesAreNotEqual() {
        assertThat(Username.of("Alice")).isNotEqualTo(Username.of("Bob")).isNotEqualTo("Alice");
        assertThat(Username.of("Alice").hashCode()).isNotEqualTo(Username.of("Bob").hashCode());
    }

    @ParameterizedTest
    @NullSource
    @ValueSource(strings = {"", "   ", "\t\n"})
    @DisplayName("rejects a missing or blank name")
    void rejectsBlank(String raw) {
        assertThatThrownBy(() -> Username.of(raw))
                .isInstanceOfSatisfying(InvalidValueException.class, error -> {
                    assertThat(error.messageKey()).isEqualTo("validation.username.required");
                    assertThat(error.category()).isEqualTo(ErrorCategory.VALIDATION);
                });
    }

    @Test
    @DisplayName("accepts exactly 50 characters and rejects 51")
    void enforcesMaximumLength() {
        assertThat(Username.of("a".repeat(50)).display()).hasSize(50);
        assertThatThrownBy(() -> Username.of("a".repeat(51)))
                .isInstanceOfSatisfying(InvalidValueException.class, error -> {
                    assertThat(error.messageKey()).isEqualTo("validation.username.too-long");
                    assertThat(error.messageArguments()).containsExactly(Username.MAX_LENGTH);
                });
    }

    @ParameterizedTest
    @ValueSource(strings = {"admin", "ADMIN", " Admin "})
    @DisplayName("recognises the admin in any case")
    void recognisesAdmin(String raw) {
        assertThat(Username.of(raw).isAdmin()).isTrue();
    }

    @ParameterizedTest
    @ValueSource(strings = {"Alice", "administrator", "ad min"})
    @DisplayName("does not treat other names as admin")
    void othersAreNotAdmin(String raw) {
        assertThat(Username.of(raw).isAdmin()).isFalse();
    }
}
