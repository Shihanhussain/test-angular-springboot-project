package com.smbc.library.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class InputHandlingIntegrationTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper json;

    private LibraryApiClient client;

    @BeforeEach
    void setUp() {
        client = new LibraryApiClient(mvc, json);
    }

    @Test
    @DisplayName("a blank name is rejected with a helpful message")
    void rejectsBlankName() throws Exception {
        assertThat(client.login("   ").hasStatus(400).message()).isEqualTo("Please enter your name.");
    }

    @Test
    @DisplayName("blank and over-long titles are rejected, and exactly 200 characters is accepted")
    void validatesTitles() throws Exception {
        client.login("admin");

        assertThat(client.add(" ").hasStatus(400).message()).isEqualTo("Please enter a book title.");
        assertThat(client.add("b".repeat(201)).hasStatus(400).message())
                .isEqualTo("Book titles can be at most 200 characters long.");
        assertThat(client.add("b".repeat(200)).hasStatus(201).message()).contains("has been added");
    }

    @Test
    @DisplayName("apostrophes, quotes and accents survive the round trip and the messages")
    void keepsPunctuationAndAccents() throws Exception {
        client.login("admin");
        assertThat(client.add("Ender's Game").message())
                .isEqualTo("Book \"Ender's Game\" has been added to the library.");
        client.add("Les Misérables");
        client.logout();

        client.login("Zoë");
        assertThat(client.borrow("ender's game").message()).isEqualTo("You borrowed \"Ender's Game\".");
        assertThat(client.borrow("LES MISÉRABLES").message()).isEqualTo("You borrowed \"Les Misérables\".");
        assertThat(client.status().borrowedBooks()).containsExactly("Ender's Game", "Les Misérables");
        assertThat(client.logout().message()).isEqualTo("Goodbye, Zoë!");
    }
}