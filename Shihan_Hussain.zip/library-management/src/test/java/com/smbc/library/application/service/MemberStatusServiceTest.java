package com.smbc.library.application.service;

import com.smbc.library.application.result.MemberStatus;
import com.smbc.library.application.result.WaitlistEntry;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Username;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MemberStatusServiceTest {

    private final InMemoryLibrary library = new InMemoryLibrary();
    private final MemberStatusService status = library.status;

    @Test
    @DisplayName("a new member has no books and no wait lists")
    void emptyStatus() {
        assertThat(status.statusOf(library.login("Alice"))).isEqualTo(new MemberStatus(List.of(), List.of()));
    }

    @Test
    @DisplayName("shows borrowed books and wait-list positions in catalog order")
    void reportsBorrowedBooksAndWaitlists() {
        library.registerBooks("The Great Gatsby", "1984", "Dune");
        Username alice = library.login("Alice");
        Username bob = library.login("Bob");
        Username carol = library.login("Carol");
        library.lending.borrow(alice, "1984");
        library.lending.borrow(alice, "Dune");
        library.lending.borrow(bob, "The Great Gatsby");
        library.waitlist.join(carol, "Dune");
        library.waitlist.join(bob, "Dune");
        library.waitlist.join(bob, "1984");

        MemberStatus bobStatus = status.statusOf(bob);

        assertThat(bobStatus.borrowedBooks()).containsExactly(BookTitle.of("The Great Gatsby"));
        assertThat(bobStatus.waitlists()).containsExactly(
                new WaitlistEntry(BookTitle.of("1984"), 1),
                new WaitlistEntry(BookTitle.of("Dune"), 2));
        assertThat(status.statusOf(alice).borrowedBooks())
                .containsExactly(BookTitle.of("1984"), BookTitle.of("Dune"));
    }

    @Test
    @DisplayName("the returned status cannot be modified by callers")
    void statusIsImmutable() {
        MemberStatus memberStatus = status.statusOf(library.login("Alice"));

        assertThatThrownBy(() -> memberStatus.borrowedBooks().add(BookTitle.of("x")))
                .isInstanceOf(UnsupportedOperationException.class);
    }
}
