package com.smbc.library.web.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(WaitlistController.class)
class WaitlistControllerTest extends WebLayerTestSupport {

    @Test
    @DisplayName("joining reports the member's position in arrival order")
    void joins() throws Exception {
        registerBooks("1984");
        lending.borrow(member("Alice"), "1984");

        mvc.perform(postTitleAs(tokenFor("Bob"), "/api/waitlist-entries", "1984"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.message")
                        .value("You are added to the wait list of \"1984\", your position is 1."));
        mvc.perform(postTitleAs(tokenFor("Carol"), "/api/waitlist-entries", "1984"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.message")
                        .value("You are added to the wait list of \"1984\", your position is 2."));
    }

    @Test
    @DisplayName("an unregistered title cannot be wait-listed")
    void unknownBook() throws Exception {
        mvc.perform(postTitleAs(tokenFor("Bob"), "/api/waitlist-entries", "1985"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Sorry, \"1985\" is not registered."));
    }

    @Test
    @DisplayName("an available book cannot be wait-listed")
    void availableBook() throws Exception {
        registerBooks("1984");

        mvc.perform(postTitleAs(tokenFor("Alice"), "/api/waitlist-entries", "1984"))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("waitlist.book-available"))
                .andExpect(jsonPath("$.message").value("Sorry, \"1984\" is available, you can borrow it now."));
    }

    @Test
    @DisplayName("joining twice reports the current position")
    void alreadyWaiting() throws Exception {
        registerBooks("1984");
        lending.borrow(member("Alice"), "1984");
        waitlist.join(member("Bob"), "1984");
        String carol = tokenFor("Carol");
        mvc.perform(postTitleAs(carol, "/api/waitlist-entries", "1984")).andExpect(status().isCreated());

        mvc.perform(postTitleAs(carol, "/api/waitlist-entries", "1984"))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("waitlist.already-joined"))
                .andExpect(jsonPath("$.message")
                        .value("You are already on the wait list of \"1984\", your position is 2."));
    }

    @Test
    @DisplayName("joining requires a session")
    void requiresSession() throws Exception {
        mvc.perform(postTitleAs("unknown", "/api/waitlist-entries", "1984")).andExpect(status().isUnauthorized());
    }
}
