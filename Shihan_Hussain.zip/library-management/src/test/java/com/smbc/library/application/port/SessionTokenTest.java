package com.smbc.library.application.port;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

class SessionTokenTest {

    @Test
    @DisplayName("tokens with the same value are equal")
    void valueEquality() {
        assertThat(new SessionToken("abc")).isEqualTo(new SessionToken("abc")).isNotEqualTo(new SessionToken("abd"));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   "})
    @DisplayName("rejects a blank value")
    void rejectsBlank(String value) {
        assertThatIllegalArgumentException().isThrownBy(() -> new SessionToken(value));
    }

    @Test
    @DisplayName("rejects a missing value")
    void rejectsNull() {
        assertThatNullPointerException().isThrownBy(() -> new SessionToken(null));
    }

    @Test
    @DisplayName("never reveals the secret when printed, for example in logs")
    void masksValue() {
        assertThat(new SessionToken("secret-value")).hasToString("SessionToken[***]");
    }
}
