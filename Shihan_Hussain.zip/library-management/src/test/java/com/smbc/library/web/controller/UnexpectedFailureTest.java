package com.smbc.library.web.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(UnexpectedFailureTest.FailingController.class)
@Import(UnexpectedFailureTest.FailingController.class)
class UnexpectedFailureTest extends WebLayerTestSupport {

    @RestController
    static class FailingController {

        @GetMapping("/test/failure")
        String fail() {
            throw new IllegalStateException("internal detail that must not leak");
        }
    }

    @Test
    @DisplayName("an unexpected failure becomes a generic 500 without internal details")
    void hidesUnexpectedFailures() throws Exception {
        mvc.perform(get("/test/failure"))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.code").value("server.unexpected"))
                .andExpect(jsonPath("$.message").value("Something went wrong on our side. Please try again."))
                .andExpect(content().string(not(containsString("internal detail"))));
    }

    @Test
    @DisplayName("an unknown route is a 404 in the API error format")
    void unknownRoute() throws Exception {
        mvc.perform(get("/api/does-not-exist"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("request.not-found"));
    }
}
