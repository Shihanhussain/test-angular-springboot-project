package com.smbc.library.infrastructure;

import com.smbc.library.domain.exception.BookNotFoundException;
import com.smbc.library.domain.model.Book;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.infrastructure.persistence.InMemoryBookRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class InMemoryBookRepositoryTest {

    private final InMemoryBookRepository repository = new InMemoryBookRepository();

    @Test
    @DisplayName("keeps books in registration order and finds them ignoring case")
    void storesBooksInOrder() {
        Book gatsby = Book.register(BookTitle.of("The Great Gatsby"));
        Book orwell = Book.register(BookTitle.of("1984"));
        repository.save(gatsby);
        repository.save(orwell);

        assertThat(repository.findAll()).containsExactly(gatsby, orwell);
        assertThat(repository.findByTitle(BookTitle.of("the great gatsby"))).containsSame(gatsby);
        assertThat(repository.getByTitle(BookTitle.of("1984"))).isSameAs(orwell);
    }

    @Test
    @DisplayName("reports an unregistered title using the requested spelling")
    void missingBook() {
        assertThat(repository.findByTitle(BookTitle.of("1985"))).isEmpty();
        assertThatThrownBy(() -> repository.getByTitle(BookTitle.of("1985")))
                .isInstanceOfSatisfying(BookNotFoundException.class,
                        error -> assertThat(error.messageArguments()).containsExactly("1985"));
    }
}
