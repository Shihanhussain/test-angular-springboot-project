package com.smbc.library.application.service;

import com.smbc.library.application.result.WaitlistEntry;
import com.smbc.library.domain.exception.AlreadyOnWaitlistException;
import com.smbc.library.domain.exception.BookAlreadyBorrowedByMemberException;
import com.smbc.library.domain.exception.BookAvailableForBorrowingException;
import com.smbc.library.domain.exception.BookNotFoundException;
import com.smbc.library.domain.model.BookTitle;
import com.smbc.library.domain.model.Username;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class WaitlistServiceTest {

    private final InMemoryLibrary library = new InMemoryLibrary();
    private final WaitlistService waitlist = library.waitlist;
    private Username alice;
    private Username bob;
    private Username carol;

    @BeforeEach
    void setUp() {
        library.registerBooks("1984");
        alice = library.login("Alice");
        bob = library.login("Bob");
        carol = library.login("Carol");
    }

    @Test
    @DisplayName("members join the wait list of a borrowed book and learn their position")
    void joinsInOrder() {
        library.lending.borrow(alice, "1984");

        assertThat(waitlist.join(bob, "1984")).isEqualTo(new WaitlistEntry(BookTitle.of("1984"), 1));
        assertThat(waitlist.join(carol, " 1984 ")).isEqualTo(new WaitlistEntry(BookTitle.of("1984"), 2));
    }

    @Test
    @DisplayName("an unregistered title cannot be wait-listed")
    void rejectsUnknownBook() {
        assertThatThrownBy(() -> waitlist.join(bob, "1985")).isInstanceOf(BookNotFoundException.class);
    }

    @Test
    @DisplayName("an available book cannot be wait-listed")
    void rejectsAvailableBook() {
        assertThatThrownBy(() -> waitlist.join(bob, "1984"))
                .isInstanceOf(BookAvailableForBorrowingException.class);
    }

    @Test
    @DisplayName("the borrower cannot wait for their own book")
    void rejectsBorrower() {
        library.lending.borrow(alice, "1984");

        assertThatThrownBy(() -> waitlist.join(alice, "1984"))
                .isInstanceOf(BookAlreadyBorrowedByMemberException.class);
    }

    @Test
    @DisplayName("a member cannot join the same wait list twice")
    void rejectsDuplicate() {
        library.lending.borrow(alice, "1984");
        waitlist.join(bob, "1984");

        assertThatThrownBy(() -> waitlist.join(bob, "1984")).isInstanceOf(AlreadyOnWaitlistException.class);
    }
}
