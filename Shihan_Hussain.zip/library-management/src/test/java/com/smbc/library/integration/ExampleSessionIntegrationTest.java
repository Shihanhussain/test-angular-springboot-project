package com.smbc.library.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class ExampleSessionIntegrationTest {

    private static final String GATSBY = "The Great Gatsby";

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper json;

    private LibraryApiClient client;

    @BeforeEach
    void setUp() {
        client = new LibraryApiClient(mvc, json);
    }

    @Test
    @DisplayName("the example session from the specification produces the specified output")
    void replaysExampleSession() throws Exception {
        adminRegistersBooks();
        aliceBorrows1984();
        bobIsTurnedAwayAndJoinsTheWaitlist();
        carolJoinsTheWaitlistSecond();
        aliceReturns1984AndItGoesToBob();
        bobIsToldAboutTheHandOver();
        carolMovesUpAndCannotReturnABookSheDidNotBorrow();
    }

    private void adminRegistersBooks() throws Exception {
        assertThat(client.login("admin").hasStatus(201).messages())
                .containsExactly("Hello, admin!", "You have access to library management");
        assertThat(client.list().hasStatus(200).catalog()).isEmpty();
        assertThat(client.add(GATSBY).hasStatus(201).message())
                .isEqualTo("Book \"The Great Gatsby\" has been added to the library.");
        assertThat(client.add("1984").hasStatus(201).message())
                .isEqualTo("Book \"1984\" has been added to the library.");
        assertThat(client.logout().hasStatus(200).message()).isEqualTo("Goodbye, admin!");
    }

    private void aliceBorrows1984() throws Exception {
        LibraryApiClient.Response login = client.login("Alice").hasStatus(201);
        assertThat(login.messages()).containsExactly("Hello, Alice!");
        assertThat(login.borrowedBooks()).isEmpty();

        assertThat(client.list().catalog()).containsExactly("The Great Gatsby (available)", "1984 (available)");
        assertThat(client.borrow("1984").hasStatus(201).message()).isEqualTo("You borrowed \"1984\".");
        assertThat(client.list().catalog()).containsExactly("The Great Gatsby (available)", "1984 (borrowed)");
        assertThat(client.status().hasStatus(200).borrowedBooks()).containsExactly("1984");
        assertThat(client.logout().message()).isEqualTo("Goodbye, Alice!");
    }

    private void bobIsTurnedAwayAndJoinsTheWaitlist() throws Exception {
        assertThat(client.login("Bob").borrowedBooks()).isEmpty();

        assertThat(client.borrow("1985").hasStatus(404).message()).isEqualTo("Sorry, \"1985\" is not registered.");
        assertThat(client.borrow("1984").hasStatus(409).message())
                .isEqualTo("Sorry, \"1984\" is currently not available");
        assertThat(client.waitlist("1985").hasStatus(404).message()).isEqualTo("Sorry, \"1985\" is not registered.");
        assertThat(client.waitlist("1984").hasStatus(201).message())
                .isEqualTo("You are added to the wait list of \"1984\", your position is 1.");
        assertThat(client.borrow(GATSBY).message()).isEqualTo("You borrowed \"The Great Gatsby\".");

        LibraryApiClient.Response status = client.status();
        assertThat(status.borrowedBooks()).containsExactly(GATSBY);
        assertThat(status.waitlists()).containsExactly("1984 - position 1");
        assertThat(client.logout().message()).isEqualTo("Goodbye, Bob!");
    }

    private void carolJoinsTheWaitlistSecond() throws Exception {
        assertThat(client.login("Carol").borrowedBooks()).isEmpty();
        assertThat(client.waitlist("1984").message())
                .isEqualTo("You are added to the wait list of \"1984\", your position is 2.");

        LibraryApiClient.Response status = client.status();
        assertThat(status.borrowedBooks()).isEmpty();
        assertThat(status.waitlists()).containsExactly("1984 - position 2");
        assertThat(client.logout().message()).isEqualTo("Goodbye, Carol!");
    }

    private void aliceReturns1984AndItGoesToBob() throws Exception {
        LibraryApiClient.Response login = client.login("Alice");
        assertThat(login.messages()).containsExactly("Hello, Alice!");
        assertThat(login.borrowedBooks()).containsExactly("1984");

        assertThat(client.giveBack("1984").hasStatus(200).message()).isEqualTo("You returned \"1984\".");
        assertThat(client.list().catalog()).containsExactly("The Great Gatsby (borrowed)", "1984 (borrowed)");
        assertThat(client.logout().message()).isEqualTo("Goodbye, Alice!");
    }

    private void bobIsToldAboutTheHandOver() throws Exception {
        LibraryApiClient.Response login = client.login("Bob");
        assertThat(login.messages()).containsExactly("Hello, Bob!", "You got the book \"1984\" from your waitlist");
        assertThat(login.borrowedBooks()).containsExactly(GATSBY, "1984");
        assertThat(login.waitlists()).isEmpty();
        assertThat(client.logout().message()).isEqualTo("Goodbye, Bob!");
    }

    private void carolMovesUpAndCannotReturnABookSheDidNotBorrow() throws Exception {
        LibraryApiClient.Response login = client.login("Carol");
        assertThat(login.messages()).containsExactly("Hello, Carol!");
        assertThat(login.borrowedBooks()).isEmpty();
        assertThat(login.waitlists()).containsExactly("1984 - position 1");

        assertThat(client.list().catalog()).containsExactly("The Great Gatsby (borrowed)", "1984 (borrowed)");
        assertThat(client.giveBack(GATSBY).hasStatus(409).message())
                .isEqualTo("Sorry, you didn't borrow \"The Great Gatsby\"");

        client.logout();
        assertThat(client.status().hasStatus(401).message()).isEqualTo("Please log in first.");
    }
}
