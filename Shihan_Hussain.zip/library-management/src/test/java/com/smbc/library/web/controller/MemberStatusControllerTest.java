package com.smbc.library.web.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(MemberStatusController.class)
class MemberStatusControllerTest extends WebLayerTestSupport {

    @Test
    @DisplayName("returns the current member's borrowed books and wait-list positions")
    void returnsStatus() throws Exception {
        registerBooks("1984", "Dune");
        lending.borrow(member("Alice"), "1984");
        lending.borrow(member("Bob"), "Dune");
        waitlist.join(member("Carol"), "Dune");
        waitlist.join(member("Alice"), "Dune");

        mvc.perform(getAs(tokenFor("Alice"), "/api/members/me/status"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.borrowedBooks", contains("1984")))
                .andExpect(jsonPath("$.waitlists.length()").value(1))
                .andExpect(jsonPath("$.waitlists[0].title").value("Dune"))
                .andExpect(jsonPath("$.waitlists[0].position").value(2));
    }

    @Test
    @DisplayName("an empty status has empty lists, not nulls")
    void emptyStatus() throws Exception {
        mvc.perform(getAs(tokenFor("Alice"), "/api/members/me/status"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.borrowedBooks", empty()))
                .andExpect(jsonPath("$.waitlists", empty()));
    }

    @Test
    @DisplayName("requires a session")
    void requiresSession() throws Exception {
        mvc.perform(get("/api/members/me/status")).andExpect(status().isUnauthorized());
    }
}
