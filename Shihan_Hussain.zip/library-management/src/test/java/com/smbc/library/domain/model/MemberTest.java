package com.smbc.library.domain.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

class MemberTest {

    @Test
    @DisplayName("a registered member keeps their name and has no notices")
    void registersMember() {
        Member member = Member.register(Username.of("Alice"));

        assertThat(member.username()).isEqualTo(Username.of("alice"));
        assertThat(member.isAdmin()).isFalse();
        assertThat(member.collectHandOverNotices()).isEmpty();
    }

    @Test
    @DisplayName("the member named admin is the administrator")
    void adminMember() {
        assertThat(Member.register(Username.of("admin")).isAdmin()).isTrue();
    }

    @Test
    @DisplayName("requires a username")
    void requiresUsername() {
        assertThatNullPointerException().isThrownBy(() -> Member.register(null));
    }

    @Test
    @DisplayName("hand-over notices are delivered in order and only once")
    void deliversNoticesOnce() {
        Member member = Member.register(Username.of("Bob"));
        member.notifyHandOver(BookTitle.of("1984"));
        member.notifyHandOver(BookTitle.of("Dune"));

        assertThat(member.collectHandOverNotices())
                .containsExactly(BookTitle.of("1984"), BookTitle.of("Dune"));
        assertThat(member.collectHandOverNotices()).isEmpty();
    }
}
