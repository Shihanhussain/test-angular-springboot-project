package com.smbc.library.integration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

final class LibraryApiClient {

    private final MockMvc mvc;
    private final ObjectMapper json;
    private String token;

    LibraryApiClient(MockMvc mvc, ObjectMapper json) {
        this.mvc = mvc;
        this.json = json;
    }

    Response login(String username) throws Exception {
        Response response = send(post("/api/sessions"), Map.of("username", username));
        token = response.body().path("token").asText(null);
        return response;
    }

    Response logout() throws Exception {
        return send(delete("/api/sessions/current"), null);
    }

    Response add(String title) throws Exception {
        return send(post("/api/books"), Map.of("title", title));
    }

    Response list() throws Exception {
        return send(get("/api/books"), null);
    }

    Response borrow(String title) throws Exception {
        return send(post("/api/loans"), Map.of("title", title));
    }

    Response giveBack(String title) throws Exception {
        return send(post("/api/returns"), Map.of("title", title));
    }

    Response waitlist(String title) throws Exception {
        return send(post("/api/waitlist-entries"), Map.of("title", title));
    }

    Response status() throws Exception {
        return send(get("/api/members/me/status"), null);
    }

    private Response send(MockHttpServletRequestBuilder request, Object body) throws Exception {
        if (token != null) {
            request.header(HttpHeaders.AUTHORIZATION, "Bearer " + token);
        }
        if (body != null) {
            request.contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(body));
        }
        MvcResult result = mvc.perform(request).andReturn();
        String content = result.getResponse().getContentAsString();
        return new Response(result.getResponse().getStatus(), content.isEmpty() ? json.nullNode() : json.readTree(content));
    }

    record Response(int status, JsonNode body) {

        String message() {
            return body.path("message").asText();
        }

        List<String> messages() {
            List<String> lines = new ArrayList<>();
            lines.add(body.path("greeting").asText());
            body.path("notices").forEach(notice -> lines.add(notice.path("message").asText()));
            return lines;
        }

        List<String> catalog() {
            List<String> lines = new ArrayList<>();
            body.forEach(book -> lines.add(book.path("title").asText() + " ("
                    + book.path("status").asText().toLowerCase() + ")"));
            return lines;
        }

        List<String> borrowedBooks() {
            return texts(statusNode().path("borrowedBooks"));
        }

        List<String> waitlists() {
            List<String> lines = new ArrayList<>();
            statusNode().path("waitlists").forEach(entry -> lines.add(
                    entry.path("title").asText() + " - position " + entry.path("position").asInt()));
            return lines;
        }

        Response hasStatus(int expected) {
            assertThat(status).as("HTTP status of %s", body).isEqualTo(expected);
            return this;
        }

        private JsonNode statusNode() {
            return body.has("status") ? body.path("status") : body;
        }

        private static List<String> texts(JsonNode array) {
            List<String> values = new ArrayList<>();
            array.forEach(node -> values.add(node.asText()));
            return values;
        }
    }
}
