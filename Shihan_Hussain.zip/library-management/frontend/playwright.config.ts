import { defineConfig } from '@playwright/test';

const port = 8181;

// Runs against the packaged app (build it first with ./mvnw package) in the locally installed Chrome.
// A fresh server is started for every run, so each run begins with an empty library.
export default defineConfig({
  testDir: './e2e',
  fullyParallel: false,
  workers: 1,
  reporter: 'list',
  use: {
    baseURL: `http://localhost:${port}`,
    channel: 'chrome',
    trace: 'retain-on-failure',
  },
  webServer: {
    command: `java -jar ../target/library.jar --server.port=${port}`,
    url: `http://localhost:${port}/actuator/health`,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});