export type BookStatus = 'AVAILABLE' | 'BORROWED';

export interface Book {
  title: string;
  status: BookStatus;
}

export interface WaitlistEntry {
  title: string;
  position: number;
}

export interface MemberStatus {
  borrowedBooks: string[];
  waitlists: WaitlistEntry[];
}

export interface LoginNotice {
  type: 'ADMIN_ACCESS' | 'HAND_OVER';
  message: string;
}

export interface LoginResponse {
  token: string;
  username: string;
  admin: boolean;
  greeting: string;
  notices: LoginNotice[];
  status: MemberStatus;
}

export interface MessageResponse {
  message: string;
}

export interface ApiError {
  code: string;
  message: string;
}

export interface Session {
  token: string;
  username: string;
  admin: boolean;
  greeting: string;
}
