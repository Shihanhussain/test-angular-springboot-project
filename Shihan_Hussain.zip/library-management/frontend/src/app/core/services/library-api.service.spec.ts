import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Observable } from 'rxjs';
import { LibraryApiService } from './library-api.service';

describe('LibraryApiService', () => {
  let api: LibraryApiService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    api = TestBed.inject(LibraryApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('lists the catalog', () => {
    let titles: string[] = [];
    api.listBooks().subscribe((books) => (titles = books.map((b) => b.title)));

    const request = http.expectOne('/api/books');
    expect(request.request.method).toBe('GET');
    request.flush([{ title: '1984', status: 'AVAILABLE' }]);

    expect(titles).toEqual(['1984']);
  });

  it('loads the member status', () => {
    api.memberStatus().subscribe();

    expect(http.expectOne('/api/members/me/status').request.method).toBe('GET');
  });

  const commands: [string, (title: string) => Observable<unknown>, string][] = [
    ['adds a book', (t) => api.addBook(t), '/api/books'],
    ['borrows a book', (t) => api.borrow(t), '/api/loans'],
    ['returns a book', (t) => api.returnBook(t), '/api/returns'],
    ['joins a wait list', (t) => api.joinWaitlist(t), '/api/waitlist-entries'],
  ];

  commands.forEach(([behaviour, call, url]) => {
    it(`${behaviour} by posting its title`, () => {
      call('The Great Gatsby').subscribe();

      const request = http.expectOne(url);
      expect(request.request.method).toBe('POST');
      expect(request.request.body).toEqual({ title: 'The Great Gatsby' });
    });
  });
});
