import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { AuthService } from './auth.service';
import { LoginResponse } from '../models/library.models';
import { loginResponse } from '../../testing/login-fixtures';

describe('AuthService', () => {
  let auth: AuthService;
  let http: HttpTestingController;

  const bobLogin: LoginResponse = loginResponse('Bob', {
    notices: [{ type: 'HAND_OVER', message: 'You got the book "1984" from your waitlist' }],
    status: { borrowedBooks: ['1984'], waitlists: [] },
  });

  function setUp(): void {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    auth = TestBed.inject(AuthService);
    http = TestBed.inject(HttpTestingController);
  }

  function signInAsBob(): void {
    auth.login('Bob').subscribe();
    http.expectOne('/api/sessions').flush(bobLogin);
  }

  beforeEach(() => sessionStorage.clear());
  afterEach(() => http.verify());

  it('starts signed out when nothing is stored', () => {
    setUp();

    expect(auth.isLoggedIn()).toBeFalse();
    expect(auth.session()).toBeNull();
  });

  it('logs in and keeps the session, greeting and login notices', () => {
    setUp();

    let response: LoginResponse | undefined;
    auth.login('Bob').subscribe((r) => (response = r));
    const request = http.expectOne('/api/sessions');
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({ username: 'Bob' });
    request.flush(bobLogin);

    expect(response).toEqual(bobLogin);
    expect(auth.isLoggedIn()).toBeTrue();
    expect(auth.session()).toEqual({ token: 'bob-token', username: 'Bob', admin: false, greeting: 'Hello, Bob!' });
    expect(auth.notices()).toEqual(bobLogin.notices);
  });

  it('restores the session and greeting after a page refresh, but not the one-time notices', () => {
    setUp();
    signInAsBob();

    TestBed.resetTestingModule();
    setUp();

    expect(auth.session()).toEqual({ token: 'bob-token', username: 'Bob', admin: false, greeting: 'Hello, Bob!' });
    expect(auth.notices()).toEqual([]);
  });

  it('ignores a corrupted stored session', () => {
    sessionStorage.setItem('smbc-library.session', '{not json');
    setUp();

    expect(auth.isLoggedIn()).toBeFalse();
  });

  it('logs out and forgets the session', () => {
    setUp();
    signInAsBob();

    let farewell = '';
    auth.logout().subscribe((r) => (farewell = r.message));
    const request = http.expectOne('/api/sessions/current');
    expect(request.request.method).toBe('DELETE');
    request.flush({ message: 'Goodbye, Bob!' });

    expect(farewell).toBe('Goodbye, Bob!');
    expect(auth.isLoggedIn()).toBeFalse();
    expect(auth.notices()).toEqual([]);
    expect(sessionStorage.length).toBe(0);
  });

  it('forgets the session even when the server rejects the logout', () => {
    setUp();
    signInAsBob();

    auth.logout().subscribe({ error: () => undefined });
    http.expectOne('/api/sessions/current').flush({}, { status: 401, statusText: 'Unauthorized' });

    expect(auth.isLoggedIn()).toBeFalse();
  });

  it('can dismiss the login notices', () => {
    setUp();
    signInAsBob();

    auth.dismissNotices();

    expect(auth.notices()).toEqual([]);
    expect(auth.isLoggedIn()).toBeTrue();
  });
});