import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Observable, finalize, tap } from 'rxjs';
import { LoginNotice, LoginResponse, MessageResponse, Session } from '../models/library.models';

// sessionStorage: survives a page refresh, but not closing the tab.
const STORAGE_KEY = 'smbc-library.session';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly current = signal<Session | null>(restoreSession());
  private readonly loginNotices = signal<LoginNotice[]>([]);

  readonly session = this.current.asReadonly();
  readonly isLoggedIn = computed(() => this.current() !== null);
  readonly notices = this.loginNotices.asReadonly();

  login(username: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>('/api/sessions', { username }).pipe(
      tap((response) => {
        this.store({
          token: response.token,
          username: response.username,
          admin: response.admin,
          greeting: response.greeting,
        });
        this.loginNotices.set(response.notices);
      }),
    );
  }

  logout(): Observable<MessageResponse> {
    return this.http.delete<MessageResponse>('/api/sessions/current').pipe(finalize(() => this.clear()));
  }

  clear(): void {
    sessionStorage.removeItem(STORAGE_KEY);
    this.current.set(null);
    this.loginNotices.set([]);
  }

  dismissNotices(): void {
    this.loginNotices.set([]);
  }

  private store(session: Session): void {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(session));
    this.current.set(session);
  }
}

function restoreSession(): Session | null {
  const stored = sessionStorage.getItem(STORAGE_KEY);
  if (!stored) {
    return null;
  }
  try {
    return JSON.parse(stored) as Session;
  } catch {
    sessionStorage.removeItem(STORAGE_KEY);
    return null;
  }
}
