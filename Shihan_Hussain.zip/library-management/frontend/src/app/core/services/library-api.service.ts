import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Book, MemberStatus, MessageResponse } from '../models/library.models';

@Injectable({ providedIn: 'root' })
export class LibraryApiService {
  private readonly http = inject(HttpClient);

  listBooks(): Observable<Book[]> {
    return this.http.get<Book[]>('/api/books');
  }

  memberStatus(): Observable<MemberStatus> {
    return this.http.get<MemberStatus>('/api/members/me/status');
  }

  addBook(title: string): Observable<MessageResponse> {
    return this.http.post<MessageResponse>('/api/books', { title });
  }

  borrow(title: string): Observable<MessageResponse> {
    return this.http.post<MessageResponse>('/api/loans', { title });
  }

  returnBook(title: string): Observable<MessageResponse> {
    return this.http.post<MessageResponse>('/api/returns', { title });
  }

  joinWaitlist(title: string): Observable<MessageResponse> {
    return this.http.post<MessageResponse>('/api/waitlist-entries', { title });
  }
}
