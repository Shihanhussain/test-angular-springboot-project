import { TestBed } from '@angular/core/testing';
import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router, provideRouter } from '@angular/router';
import { authTokenInterceptor } from './auth-token.interceptor';
import { sessionExpiredInterceptor } from './session-expired.interceptor';
import { AuthService } from '../services/auth.service';
import { loginResponse } from '../../testing/login-fixtures';

describe('HTTP interceptors', () => {
  let client: HttpClient;
  let http: HttpTestingController;
  let auth: AuthService;
  let router: Router;

  beforeEach(() => {
    sessionStorage.clear();
    TestBed.configureTestingModule({
      providers: [
        provideRouter([]),
        provideHttpClient(withInterceptors([authTokenInterceptor, sessionExpiredInterceptor])),
        provideHttpClientTesting(),
      ],
    });
    client = TestBed.inject(HttpClient);
    http = TestBed.inject(HttpTestingController);
    auth = TestBed.inject(AuthService);
    router = TestBed.inject(Router);
  });

  afterEach(() => http.verify());

  function signIn(): void {
    auth.login('Alice').subscribe();
    http.expectOne('/api/sessions').flush(loginResponse('Alice', { token: 'alice-token', admin: false }));
  }

  describe('authTokenInterceptor', () => {
    it('sends the bearer token with API calls when signed in', () => {
      signIn();

      client.get('/api/books').subscribe();

      expect(http.expectOne('/api/books').request.headers.get('Authorization')).toBe('Bearer alice-token');
    });

    it('sends no credentials when signed out', () => {
      client.get('/api/books').subscribe();

      expect(http.expectOne('/api/books').request.headers.has('Authorization')).toBeFalse();
    });

    it('never sends the token to other hosts', () => {
      signIn();

      client.get('https://example.com/api/books').subscribe();

      expect(http.expectOne('https://example.com/api/books').request.headers.has('Authorization')).toBeFalse();
    });
  });

  describe('sessionExpiredInterceptor', () => {
    it('signs out and goes to the login page when the server no longer knows the session', () => {
      signIn();
      const navigate = spyOn(router, 'navigate').and.resolveTo(true);

      client.get('/api/books').subscribe({ error: () => undefined });
      http
        .expectOne('/api/books')
        .flush({ message: 'Please log in first.' }, { status: 401, statusText: 'Unauthorized' });

      expect(auth.isLoggedIn()).toBeFalse();
      expect(navigate).toHaveBeenCalledWith(['/login']);
    });

    it('passes other errors through untouched', () => {
      signIn();
      let status = 0;

      client.get('/api/books').subscribe({ error: (e) => (status = e.status) });
      http.expectOne('/api/books').flush({}, { status: 409, statusText: 'Conflict' });

      expect(status).toBe(409);
      expect(auth.isLoggedIn()).toBeTrue();
    });
  });
});
