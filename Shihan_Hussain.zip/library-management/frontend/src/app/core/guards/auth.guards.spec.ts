import { TestBed } from '@angular/core/testing';
import { loginResponse } from '../../testing/login-fixtures';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot, UrlTree, provideRouter } from '@angular/router';
import { authGuard, guestGuard } from './auth.guards';
import { AuthService } from '../services/auth.service';

describe('route guards', () => {
  let auth: AuthService;
  let router: Router;
  let http: HttpTestingController;
  const route = {} as ActivatedRouteSnapshot;
  const state = {} as RouterStateSnapshot;

  beforeEach(() => {
    sessionStorage.clear();
    TestBed.configureTestingModule({
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    });
    auth = TestBed.inject(AuthService);
    router = TestBed.inject(Router);
    http = TestBed.inject(HttpTestingController);
  });

  function signIn(): void {
    auth.login('Alice').subscribe();
    http.expectOne('/api/sessions').flush(loginResponse('Alice', { token: 't', admin: false }));
  }

  const run = (guard: typeof authGuard) => TestBed.runInInjectionContext(() => guard(route, state));

  it('lets signed-in members into the library', () => {
    signIn();
    expect(run(authGuard)).toBeTrue();
  });

  it('sends signed-out visitors to the login page', () => {
    const result = run(authGuard) as UrlTree;
    expect(router.serializeUrl(result)).toBe('/login');
  });

  it('shows the login page to signed-out visitors', () => {
    expect(run(guestGuard)).toBeTrue();
  });

  it('sends signed-in members from the login page to the library', () => {
    signIn();
    const result = run(guestGuard) as UrlTree;
    expect(router.serializeUrl(result)).toBe('/library');
  });
});
