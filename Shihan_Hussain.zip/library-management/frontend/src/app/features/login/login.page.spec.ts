import { ComponentFixture, TestBed } from '@angular/core/testing';
import { loginResponse } from '../../testing/login-fixtures';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router, provideRouter } from '@angular/router';
import { LoginPage } from './login.page';
import { textbox, type } from '../../testing/dom-queries';

describe('LoginPage', () => {
  let fixture: ComponentFixture<LoginPage>;
  let http: HttpTestingController;
  let router: Router;
  let element: HTMLElement;

  beforeEach(() => {
    sessionStorage.clear();
    TestBed.configureTestingModule({
      imports: [LoginPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    });
    fixture = TestBed.createComponent(LoginPage);
    http = TestBed.inject(HttpTestingController);
    router = TestBed.inject(Router);
    element = fixture.nativeElement;
    fixture.detectChanges();
  });

  afterEach(() => http.verify());

  function typeName(name: string): void {
    type(textbox(element, 'Your name'), name);
    fixture.detectChanges();
  }

  function submit(): void {
    element.querySelector('form')!.dispatchEvent(new Event('submit'));
    fixture.detectChanges();
  }

  it('does not send a blank name and explains why', () => {
    typeName('   ');
    submit();

    http.expectNone('/api/sessions');
    expect(element.textContent).toContain('Please enter your name.');
  });

  it('does not send a name longer than 50 characters', () => {
    typeName('a'.repeat(51));
    submit();

    http.expectNone('/api/sessions');
    expect(element.textContent).toContain('Names can be at most 50 characters long.');
  });

  it('signs in with the trimmed name and opens the library', () => {
    const navigate = spyOn(router, 'navigate').and.resolveTo(true);
    typeName('  Alice ');
    submit();

    const request = http.expectOne('/api/sessions');
    expect(request.request.body).toEqual({ username: 'Alice' });
    request.flush(loginResponse('Alice', { token: 't', admin: false }));

    expect(navigate).toHaveBeenCalledWith(['/library']);
  });

  it('shows the server explanation when sign-in fails', () => {
    typeName('Alice');
    submit();

    http.expectOne('/api/sessions').flush(
      { code: 'validation.username.required', message: 'Please enter your name.' },
      { status: 400, statusText: 'Bad Request' },
    );
    fixture.detectChanges();

    expect(element.querySelector('[role="alert"]')!.textContent).toContain('Please enter your name.');
  });
});
