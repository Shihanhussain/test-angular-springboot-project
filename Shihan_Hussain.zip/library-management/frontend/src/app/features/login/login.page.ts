import { Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { AuthService } from '../../core/services/auth.service';
import { errorMessage } from '../../shared/api-error';
import { USERNAME_MAX_LENGTH, notBlank } from '../../shared/validators';

@Component({
  selector: 'app-login-page',
  imports: [ReactiveFormsModule, MatProgressBarModule],
  templateUrl: './login.page.html',
  styleUrl: './login.page.scss',
})
export class LoginPage {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  readonly maxLength = USERNAME_MAX_LENGTH;
  readonly submitting = signal(false);
  readonly serverError = signal('');
  readonly form = new FormGroup({
    username: new FormControl('', {
      nonNullable: true,
      validators: [notBlank, Validators.maxLength(USERNAME_MAX_LENGTH)],
    }),
  });

  showUsernameError(): boolean {
    const control = this.form.controls.username;
    return control.invalid && control.touched;
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting.set(true);
    this.serverError.set('');
    this.auth.login(this.form.controls.username.value.trim()).subscribe({
      next: () => void this.router.navigate(['/library']),
      error: (error: unknown) => {
        this.serverError.set(errorMessage(error));
        this.submitting.set(false);
      },
    });
  }
}