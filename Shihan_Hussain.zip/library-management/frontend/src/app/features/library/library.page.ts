import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { Observable, finalize, forkJoin } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';
import { LibraryApiService } from '../../core/services/library-api.service';
import { Book, MemberStatus, MessageResponse } from '../../core/models/library.models';
import { NotificationService } from '../../shared/notification.service';
import { errorMessage } from '../../shared/api-error';
import { AddBookFormComponent } from './components/add-book-form/add-book-form.component';
import { BookCatalogComponent } from './components/book-catalog/book-catalog.component';
import { MemberStatusComponent } from './components/member-status/member-status.component';

@Component({
  selector: 'app-library-page',
  imports: [MatProgressBarModule, AddBookFormComponent, BookCatalogComponent, MemberStatusComponent],
  templateUrl: './library.page.html',
  styleUrl: './library.page.scss',
})
export class LibraryPage implements OnInit {
  private readonly api = inject(LibraryApiService);
  private readonly auth = inject(AuthService);
  private readonly notifications = inject(NotificationService);

  readonly session = this.auth.session;
  readonly notices = this.auth.notices;
  readonly initial = computed(() => this.session()?.username.charAt(0).toUpperCase() ?? '');
  readonly books = signal<Book[]>([]);
  readonly memberStatus = signal<MemberStatus>({ borrowedBooks: [], waitlists: [] });
  readonly loading = signal(true);
  readonly busy = signal(false);

  ngOnInit(): void {
    this.refresh();
  }

  dismissNotices(): void {
    this.auth.dismissNotices();
  }

  addBook(title: string): void {
    this.perform(this.api.addBook(title));
  }

  borrow(title: string): void {
    this.perform(this.api.borrow(title));
  }

  returnBook(title: string): void {
    this.perform(this.api.returnBook(title));
  }

  joinWaitlist(title: string): void {
    this.perform(this.api.joinWaitlist(title));
  }

  private perform(action: Observable<MessageResponse>): void {
    this.busy.set(true);
    action.pipe(finalize(() => this.busy.set(false))).subscribe({
      next: (response) => {
        this.notifications.success(response.message);
        this.refresh();
      },
      error: (error: unknown) => this.notifications.error(errorMessage(error)),
    });
  }

  private refresh(): void {
    forkJoin({ books: this.api.listBooks(), status: this.api.memberStatus() })
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: ({ books, status }) => {
          this.books.set(books);
          this.memberStatus.set(status);
        },
        error: (error: unknown) => this.notifications.error(errorMessage(error)),
      });
  }
}