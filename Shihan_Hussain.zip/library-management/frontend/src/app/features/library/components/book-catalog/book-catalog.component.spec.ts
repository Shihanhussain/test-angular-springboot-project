import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BookCatalogComponent, bookAction } from './book-catalog.component';
import { Book, MemberStatus } from '../../../../core/models/library.models';
import { button, listItem, listItems } from '../../../../testing/dom-queries';

describe('bookAction', () => {
  const status: MemberStatus = { borrowedBooks: ['Dune'], waitlists: [{ title: '1984', position: 2 }] };

  it('offers to borrow an available book', () => {
    expect(bookAction({ title: 'Emma', status: 'AVAILABLE' }, status)).toEqual({ kind: 'borrow' });
  });

  it('offers to return a book the member holds', () => {
    expect(bookAction({ title: 'Dune', status: 'BORROWED' }, status)).toEqual({ kind: 'return' });
  });

  it('shows the position for a book the member is waiting for', () => {
    expect(bookAction({ title: '1984', status: 'BORROWED' }, status)).toEqual({ kind: 'waiting', position: 2 });
  });

  it('offers the wait list for a book someone else holds', () => {
    expect(bookAction({ title: 'Ulysses', status: 'BORROWED' }, status)).toEqual({ kind: 'waitlist' });
  });
});

describe('BookCatalogComponent', () => {
  let fixture: ComponentFixture<BookCatalogComponent>;
  let catalog: HTMLElement;

  const books: Book[] = [
    { title: 'The Great Gatsby', status: 'AVAILABLE' },
    { title: '1984', status: 'BORROWED' },
    { title: 'Dune', status: 'BORROWED' },
    { title: 'Emma', status: 'BORROWED' },
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [BookCatalogComponent] });
    fixture = TestBed.createComponent(BookCatalogComponent);
    fixture.componentRef.setInput('books', books);
    fixture.componentRef.setInput('memberStatus', {
      borrowedBooks: ['Dune'],
      waitlists: [{ title: 'Emma', position: 3 }],
    });
    catalog = fixture.nativeElement;
    fixture.detectChanges();
  });

  it('lists every book in catalog order with its status', () => {
    const rows = listItems(catalog).map((row) => row.textContent);

    expect(rows.length).toBe(4);
    expect(rows[0]).toContain('The Great Gatsby');
    expect(rows[0]).toContain('Available');
    expect(rows[1]).toContain('Borrowed');
  });

  it('emits the title when the member borrows, returns or joins a wait list', () => {
    const borrowed: string[] = [];
    const returned: string[] = [];
    const waited: string[] = [];
    fixture.componentInstance.borrow.subscribe((t) => borrowed.push(t));
    fixture.componentInstance.giveBack.subscribe((t) => returned.push(t));
    fixture.componentInstance.joinWaitlist.subscribe((t) => waited.push(t));

    button(listItem(catalog, 'The Great Gatsby'), 'Borrow').click();
    button(listItem(catalog, 'Dune'), 'Return').click();
    button(listItem(catalog, '1984'), 'Join wait list').click();

    expect(borrowed).toEqual(['The Great Gatsby']);
    expect(returned).toEqual(['Dune']);
    expect(waited).toEqual(['1984']);
  });

  it('shows the queue position instead of a button for a book the member is waiting for', () => {
    const row = listItem(catalog, 'Emma');

    expect(row.textContent).toContain('#3');
    expect(row.querySelector('button')).toBeNull();
  });

  it('disables actions while a request is running', () => {
    fixture.componentRef.setInput('busy', true);
    fixture.detectChanges();

    expect(Array.from(catalog.querySelectorAll('button')).every((b) => b.disabled)).toBeTrue();
  });

  it('tells the member when the catalog is empty', () => {
    fixture.componentRef.setInput('books', []);
    fixture.detectChanges();

    expect(catalog.textContent).toContain('No books are registered');
    expect(listItems(catalog)).toEqual([]);
  });
});