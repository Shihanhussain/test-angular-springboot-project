import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MemberStatusComponent } from './member-status.component';
import { region } from '../../../../testing/dom-queries';

describe('MemberStatusComponent', () => {
  let fixture: ComponentFixture<MemberStatusComponent>;
  let element: HTMLElement;

  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [MemberStatusComponent] });
    fixture = TestBed.createComponent(MemberStatusComponent);
    element = fixture.nativeElement;
  });

  it('says when nothing is borrowed and no wait list is joined', () => {
    fixture.componentRef.setInput('status', { borrowedBooks: [], waitlists: [] });
    fixture.detectChanges();

    expect(region(element, 'Your borrowed books').textContent).toContain("You don't have any books borrowed yet.");
    expect(region(element, 'Your wait lists').textContent).toContain('You are not on any wait list.');
  });

  it('lists borrowed books and wait-list positions with their counts', () => {
    fixture.componentRef.setInput('status', {
      borrowedBooks: ['The Great Gatsby', 'Dune'],
      waitlists: [{ title: '1984', position: 1 }],
    });
    fixture.detectChanges();

    const borrowed = region(element, 'Your borrowed books');
    const waiting = region(element, 'Your wait lists');
    expect(borrowed.textContent).toContain('The Great Gatsby');
    expect(borrowed.querySelector('[aria-label="2 books"]')).not.toBeNull();
    expect(waiting.textContent).toContain('1984');
    expect(waiting.textContent).toContain('Position 1');
    expect(waiting.querySelector('[aria-label="1 title"]')).not.toBeNull();
  });
});