import { Component, input, output } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, ReactiveFormsModule, Validators } from '@angular/forms';
import { TITLE_MAX_LENGTH, notBlank } from '../../../../shared/validators';

@Component({
  selector: 'app-add-book-form',
  imports: [ReactiveFormsModule],
  templateUrl: './add-book-form.component.html',
  styleUrl: './add-book-form.component.scss',
})
export class AddBookFormComponent {
  readonly busy = input(false);
  readonly add = output<string>();

  readonly maxLength = TITLE_MAX_LENGTH;
  readonly form = new FormGroup({
    title: new FormControl('', {
      nonNullable: true,
      validators: [notBlank, Validators.maxLength(TITLE_MAX_LENGTH)],
    }),
  });

  showError(): boolean {
    const control = this.form.controls.title;
    return control.invalid && control.touched;
  }

  submit(formDirective: FormGroupDirective): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.add.emit(this.form.controls.title.value.trim());
    formDirective.resetForm();
  }
}