import { Component, input } from '@angular/core';
import { MemberStatus } from '../../../../core/models/library.models';

@Component({
  selector: 'app-member-status',
  templateUrl: './member-status.component.html',
  styleUrl: './member-status.component.scss',
})
export class MemberStatusComponent {
  readonly status = input.required<MemberStatus>();
}