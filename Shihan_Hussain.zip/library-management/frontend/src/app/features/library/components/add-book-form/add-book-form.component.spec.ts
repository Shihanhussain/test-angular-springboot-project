import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddBookFormComponent } from './add-book-form.component';
import { textbox, type } from '../../../../testing/dom-queries';

describe('AddBookFormComponent', () => {
  let fixture: ComponentFixture<AddBookFormComponent>;
  let element: HTMLElement;
  let added: string[];

  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [AddBookFormComponent] });
    fixture = TestBed.createComponent(AddBookFormComponent);
    element = fixture.nativeElement;
    added = [];
    fixture.componentInstance.add.subscribe((title) => added.push(title));
    fixture.detectChanges();
  });

  function typeTitle(title: string): HTMLInputElement {
    const input = textbox(element, 'Book title');
    type(input, title);
    fixture.detectChanges();
    return input;
  }

  function submit(): void {
    element.querySelector('form')!.dispatchEvent(new Event('submit'));
    fixture.detectChanges();
  }

  it('emits the trimmed title and clears the field', () => {
    const input = typeTitle('  The Great Gatsby ');
    submit();

    expect(added).toEqual(['The Great Gatsby']);
    expect(input.value).toBe('');
  });

  it('does not emit a blank title', () => {
    typeTitle('   ');
    submit();

    expect(added).toEqual([]);
    expect(element.textContent).toContain('Please enter a book title.');
  });

  it('does not emit a title longer than 200 characters', () => {
    typeTitle('b'.repeat(201));
    submit();

    expect(added).toEqual([]);
    expect(element.textContent).toContain('Book titles can be at most 200 characters long.');
  });
});
