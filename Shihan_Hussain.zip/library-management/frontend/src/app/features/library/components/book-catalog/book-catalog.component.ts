import { Component, input, output } from '@angular/core';
import { Book, MemberStatus } from '../../../../core/models/library.models';

export type BookAction =
  | { kind: 'borrow' }
  | { kind: 'return' }
  | { kind: 'waitlist' }
  | { kind: 'waiting'; position: number };

export function bookAction(book: Book, status: MemberStatus): BookAction {
  if (status.borrowedBooks.includes(book.title)) {
    return { kind: 'return' };
  }
  const entry = status.waitlists.find((w) => w.title === book.title);
  if (entry) {
    return { kind: 'waiting', position: entry.position };
  }
  return book.status === 'AVAILABLE' ? { kind: 'borrow' } : { kind: 'waitlist' };
}

@Component({
  selector: 'app-book-catalog',
  templateUrl: './book-catalog.component.html',
  styleUrl: './book-catalog.component.scss',
})
export class BookCatalogComponent {
  readonly books = input.required<Book[]>();
  readonly memberStatus = input.required<MemberStatus>();
  readonly busy = input(false);

  readonly borrow = output<string>();
  readonly giveBack = output<string>();
  readonly joinWaitlist = output<string>();

  actionFor(book: Book): BookAction {
    return bookAction(book, this.memberStatus());
  }
}
