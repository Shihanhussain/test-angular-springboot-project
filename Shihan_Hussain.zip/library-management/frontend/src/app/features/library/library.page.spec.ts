import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { LibraryPage } from './library.page';
import { AuthService } from '../../core/services/auth.service';
import { NotificationService } from '../../shared/notification.service';
import { Book, LoginNotice, MemberStatus } from '../../core/models/library.models';
import { loginResponse } from '../../testing/login-fixtures';
import { button, listItem, region, submit, textbox, type } from '../../testing/dom-queries';

describe('LibraryPage', () => {
  let fixture: ComponentFixture<LibraryPage>;
  let http: HttpTestingController;
  let notifications: jasmine.SpyObj<NotificationService>;
  let page: HTMLElement;

  const catalog: Book[] = [
    { title: 'The Great Gatsby', status: 'AVAILABLE' },
    { title: '1984', status: 'BORROWED' },
  ];
  const noBooks: MemberStatus = { borrowedBooks: [], waitlists: [] };

  function signInAs(username: string, admin = false, notices: LoginNotice[] = []): void {
    TestBed.inject(AuthService).login(username).subscribe();
    http.expectOne('/api/sessions').flush(loginResponse(username, { admin, notices }));
  }

  function open(): void {
    fixture = TestBed.createComponent(LibraryPage);
    page = fixture.nativeElement;
    fixture.detectChanges();
  }

  function respondWithLibrary(books: Book[] = catalog, status: MemberStatus = noBooks): void {
    http.expectOne('/api/books').flush(books);
    http.expectOne('/api/members/me/status').flush(status);
    fixture.detectChanges();
  }

  function statValue(label: string): string {
    return region(page, label).querySelector('strong')!.textContent!.trim();
  }

  beforeEach(() => {
    sessionStorage.clear();
    notifications = jasmine.createSpyObj<NotificationService>('NotificationService', ['success', 'error']);
    TestBed.configureTestingModule({
      imports: [LibraryPage],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: NotificationService, useValue: notifications },
      ],
    });
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('loads the catalog and the member status', () => {
    signInAs('Alice');
    open();
    respondWithLibrary();

    expect(listItem(page, 'The Great Gatsby').textContent).toContain('Available');
    expect(region(page, 'Your borrowed books').textContent).toContain("You don't have any books borrowed yet.");
  });

  it('greets the member with the server greeting and summarises the catalog, loans and wait lists', () => {
    signInAs('Alice');
    open();
    respondWithLibrary(catalog, { borrowedBooks: ['The Great Gatsby'], waitlists: [{ title: '1984', position: 1 }] });

    expect(page.querySelector('h1')!.textContent).toContain('Hello, Alice!');
    expect(statValue('In the catalog')).toBe('2');
    expect(statValue('Borrowed by you')).toBe('1');
    expect(statValue('Your wait lists')).toBe('1');
  });

  it('shows each login notice by its type, without depending on the wording', () => {
    signInAs('admin', true, [
      { type: 'ADMIN_ACCESS', message: 'Admin text from the server' },
      { type: 'HAND_OVER', message: 'Hand-over text from the server' },
    ]);
    open();
    respondWithLibrary();

    expect(page.querySelector('[data-notice-type="ADMIN_ACCESS"]')!.textContent).toContain('Admin text from the server');
    expect(page.querySelector('[data-notice-type="HAND_OVER"]')!.textContent).toContain('Hand-over text from the server');
  });

  it('keeps the notices until they are dismissed', () => {
    signInAs('Bob', false, [{ type: 'HAND_OVER', message: 'You got the book "1984" from your waitlist' }]);
    open();
    respondWithLibrary();
    expect(page.textContent).toContain('You got the book "1984" from your waitlist');

    button(page, 'Dismiss messages').click();
    fixture.detectChanges();

    expect(page.textContent).not.toContain('from your waitlist');
  });

  it('borrows a book, confirms it and refreshes the library', () => {
    signInAs('Alice');
    open();
    respondWithLibrary();

    button(listItem(page, 'The Great Gatsby'), 'Borrow').click();
    const request = http.expectOne('/api/loans');
    expect(request.request.body).toEqual({ title: 'The Great Gatsby' });
    request.flush({ message: 'You borrowed "The Great Gatsby".' });
    respondWithLibrary([{ title: 'The Great Gatsby', status: 'BORROWED' }, catalog[1]], {
      borrowedBooks: ['The Great Gatsby'],
      waitlists: [],
    });

    expect(notifications.success).toHaveBeenCalledWith('You borrowed "The Great Gatsby".');
    expect(region(page, 'Your borrowed books').textContent).toContain('The Great Gatsby');
    expect(button(listItem(page, 'The Great Gatsby'), 'Return')).toBeTruthy();
  });

  it('returns a book', () => {
    signInAs('Alice');
    open();
    respondWithLibrary(catalog, { borrowedBooks: ['1984'], waitlists: [] });

    button(listItem(page, '1984'), 'Return').click();

    expect(http.expectOne('/api/returns').request.body).toEqual({ title: '1984' });
  });

  it('shows the server explanation when an action is refused', () => {
    signInAs('Alice');
    open();
    respondWithLibrary();

    button(listItem(page, '1984'), 'Join wait list').click();
    http
      .expectOne('/api/waitlist-entries')
      .flush(
        { code: 'waitlist.already-joined', message: 'You are already on the wait list of "1984", your position is 1.' },
        { status: 409, statusText: 'Conflict' },
      );

    expect(notifications.error).toHaveBeenCalledWith('You are already on the wait list of "1984", your position is 1.');
  });

  it('reports a failure to load the library', () => {
    signInAs('Alice');
    open();
    http.expectOne('/api/books').flush({ code: 'x', message: 'Please log in first.' }, { status: 401, statusText: 'Unauthorized' });
    http.expectOne('/api/members/me/status');

    expect(notifications.error).toHaveBeenCalledWith('Please log in first.');
  });

  it('offers the add-book form to the admin only', () => {
    signInAs('Alice');
    open();
    respondWithLibrary();
    expect(page.querySelector('[aria-label="Add a book"]')).toBeNull();

    fixture.destroy();
    TestBed.inject(AuthService).clear();
    signInAs('admin', true);
    open();
    respondWithLibrary();
    expect(region(page, 'Add a book')).toBeTruthy();
  });

  it('lets the admin add a book', () => {
    signInAs('admin', true);
    open();
    respondWithLibrary();

    const title = textbox(page, 'Book title');
    type(title, 'Dune');
    submit(title);

    expect(http.expectOne('/api/books').request.body).toEqual({ title: 'Dune' });
  });
});