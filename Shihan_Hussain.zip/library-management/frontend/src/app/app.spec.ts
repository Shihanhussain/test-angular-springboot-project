import { ComponentFixture, TestBed } from '@angular/core/testing';
import { loginResponse } from './testing/login-fixtures';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router, provideRouter } from '@angular/router';
import { App } from './app';
import { AuthService } from './core/services/auth.service';
import { NotificationService } from './shared/notification.service';

describe('App shell', () => {
  let fixture: ComponentFixture<App>;
  let http: HttpTestingController;
  let element: HTMLElement;
  let notifications: jasmine.SpyObj<NotificationService>;

  beforeEach(() => {
    sessionStorage.clear();
    notifications = jasmine.createSpyObj<NotificationService>('NotificationService', ['success', 'error']);
    TestBed.configureTestingModule({
      imports: [App],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: NotificationService, useValue: notifications },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    fixture = TestBed.createComponent(App);
    element = fixture.nativeElement;
    fixture.detectChanges();
  });

  afterEach(() => http.verify());

  it('shows the brand and hides account actions when signed out', () => {
    expect(element.textContent).toContain('SMBC Library');
    expect(element.textContent).not.toContain('Console');
    expect(element.querySelector('button[aria-label="Sign out"]')).toBeNull();
  });

  it('shows who is signed in and signs them out', () => {
    TestBed.inject(AuthService).login('admin').subscribe();
    http.expectOne('/api/sessions').flush(loginResponse('admin', { token: 't', admin: true }));
    fixture.detectChanges();
    expect(element.textContent).toContain('admin');
    expect(element.textContent).toContain('Librarian');

    const navigate = spyOn(TestBed.inject(Router), 'navigate').and.resolveTo(true);
    element.querySelector<HTMLButtonElement>('button[aria-label="Sign out"]')!.click();
    http.expectOne('/api/sessions/current').flush({ message: 'Goodbye, admin!' });
    fixture.detectChanges();

    expect(notifications.success).toHaveBeenCalledWith('Goodbye, admin!');
    expect(navigate).toHaveBeenCalledWith(['/login']);
    expect(element.querySelector('button[aria-label="Sign out"]')).toBeNull();
  });
});
