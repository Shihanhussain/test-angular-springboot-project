import { HttpErrorResponse } from '@angular/common/http';
import { errorMessage } from './api-error';

describe('errorMessage', () => {
  it('uses the message the server sent', () => {
    const error = new HttpErrorResponse({
      status: 404,
      error: { code: 'book.not-found', message: 'Sorry, "1985" is not registered.' },
    });

    expect(errorMessage(error)).toBe('Sorry, "1985" is not registered.');
  });

  it('explains when the server cannot be reached', () => {
    expect(errorMessage(new HttpErrorResponse({ status: 0 }))).toBe(
      'Cannot reach the library server. Please check that it is running.',
    );
  });

  it('falls back to a generic message for anything else', () => {
    expect(errorMessage(new HttpErrorResponse({ status: 502, error: '<html>' }))).toBe(
      'Something went wrong. Please try again.',
    );
    expect(errorMessage(new Error('boom'))).toBe('Something went wrong. Please try again.');
  });
});
