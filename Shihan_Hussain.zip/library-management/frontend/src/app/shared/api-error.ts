import { HttpErrorResponse } from '@angular/common/http';
import { ApiError } from '../core/models/library.models';

const UNREACHABLE = 'Cannot reach the library server. Please check that it is running.';
const GENERIC = 'Something went wrong. Please try again.';

export function errorMessage(error: unknown): string {
  if (!(error instanceof HttpErrorResponse)) {
    return GENERIC;
  }
  if (error.status === 0) {
    return UNREACHABLE;
  }
  return isApiError(error.error) ? error.error.message : GENERIC;
}

function isApiError(body: unknown): body is ApiError {
  return typeof body === 'object' && body !== null && typeof (body as ApiError).message === 'string';
}
