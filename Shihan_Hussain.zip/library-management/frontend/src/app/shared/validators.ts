import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export const notBlank: ValidatorFn = (control: AbstractControl<string | null>): ValidationErrors | null =>
  control.value?.trim() ? null : { required: true };

export const USERNAME_MAX_LENGTH = 50;
export const TITLE_MAX_LENGTH = 200;
