import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from './core/services/auth.service';
import { NotificationService } from './shared/notification.service';
import { errorMessage } from './shared/api-error';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink],
  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly notifications = inject(NotificationService);

  readonly session = this.auth.session;

  signOut(): void {
    this.auth.logout().subscribe({
      next: (response) => this.notifications.success(response.message),
      error: (error: unknown) => {
        this.notifications.error(errorMessage(error));
        void this.router.navigate(['/login']);
      },
      complete: () => void this.router.navigate(['/login']),
    });
  }
}