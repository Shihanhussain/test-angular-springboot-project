import { Routes } from '@angular/router';
import { authGuard, guestGuard } from './core/guards/auth.guards';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'library' },
  {
    path: 'login',
    title: 'Sign in · SMBC Library',
    canActivate: [guestGuard],
    loadComponent: () => import('./features/login/login.page').then((m) => m.LoginPage),
  },
  {
    path: 'library',
    title: 'Library · SMBC Library',
    canActivate: [authGuard],
    loadComponent: () => import('./features/library/library.page').then((m) => m.LibraryPage),
  },
  { path: '**', redirectTo: 'library' },
];
