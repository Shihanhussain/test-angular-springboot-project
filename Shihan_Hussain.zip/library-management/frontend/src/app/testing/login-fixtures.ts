import { LoginNotice, LoginResponse, MemberStatus } from '../core/models/library.models';

const NO_BOOKS: MemberStatus = { borrowedBooks: [], waitlists: [] };

export function loginResponse(
  username: string,
  options: { admin?: boolean; notices?: LoginNotice[]; status?: MemberStatus; token?: string } = {},
): LoginResponse {
  return {
    token: options.token ?? `${username.toLowerCase()}-token`,
    username,
    admin: options.admin ?? false,
    greeting: `Hello, ${username}!`,
    notices: options.notices ?? [],
    status: options.status ?? NO_BOOKS,
  };
}