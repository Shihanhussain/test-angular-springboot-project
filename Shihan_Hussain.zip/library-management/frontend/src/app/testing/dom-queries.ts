// Find elements by role/label/text like a user would, so CSS changes don't break specs.
export function button(root: HTMLElement, name: string): HTMLButtonElement {
  const match = Array.from(root.querySelectorAll('button')).find(
    (b) => (b.getAttribute('aria-label') ?? b.textContent ?? '').trim() === name,
  );
  if (!match) {
    throw new Error(`No button named "${name}"`);
  }
  return match;
}

export function region(root: HTMLElement, label: string): HTMLElement {
  const match = root.querySelector<HTMLElement>(`[aria-label="${label}"]`);
  if (!match) {
    throw new Error(`No region labelled "${label}"`);
  }
  return match;
}

export function listItems(root: HTMLElement): HTMLElement[] {
  return Array.from(root.querySelectorAll<HTMLElement>('[role="listitem"], li'));
}

export function listItem(root: HTMLElement, text: string): HTMLElement {
  const match = listItems(root).find((item) => item.textContent!.includes(text));
  if (!match) {
    throw new Error(`No list item containing "${text}"`);
  }
  return match;
}

export function textbox(root: HTMLElement, label: string): HTMLInputElement {
  const labelElement = Array.from(root.querySelectorAll('label')).find((l) => l.textContent!.trim() === label);
  const input = labelElement?.htmlFor ? root.querySelector<HTMLInputElement>(`#${labelElement.htmlFor}`) : null;
  if (!input) {
    throw new Error(`No text box labelled "${label}"`);
  }
  return input;
}

export function type(input: HTMLInputElement, value: string): void {
  input.value = value;
  input.dispatchEvent(new Event('input'));
  input.dispatchEvent(new Event('blur'));
}

export function submit(form: HTMLElement): void {
  (form.closest('form') ?? form.querySelector('form'))!.dispatchEvent(new Event('submit'));
}