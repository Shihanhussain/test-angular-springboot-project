# SMBC Library

A small library web app. You sign in with a name, browse the books, borrow and return them, and join a wait list when a book is already out. When a book is returned it goes straight to the first person waiting. Only `admin` can add books.

Everything is kept in memory, so each start begins with an empty library.

## Tech stack

- **Backend:** Java 21, Spring Boot 3.5 (Web, Actuator), Maven Wrapper
- **Frontend:** Angular 20, Angular Material, standalone components, built by Maven through `frontend-maven-plugin`
- **Tests:** JUnit 5, AssertJ, Mockito, Spring Boot Test, ArchUnit; Jasmine/Karma and Playwright on the frontend

## Running it

You need Java 21+ and internet access on the first run. Nothing else has to be installed: `./mvnw` downloads Maven, and the build downloads its own Node.js into `frontend/node` to build the Angular app.

```sh
./start.sh
```

This checks the Java version, builds the frontend and the backend jar, and starts it. Open http://localhost:8080 once it says it has started, and stop it with Ctrl+C. The first run takes a few minutes because of the downloads.

To use another port: `PORT=9090 ./start.sh`. If the script isn't executable after unzipping, run `sh start.sh`.

**On Windows**, run `sh start.sh` in Git Bash, or the same two steps in PowerShell:

```powershell
.\mvnw.cmd -DskipTests package
java -jar target\library.jar
```

## Using the app

1. Sign in with any name. A member is created the first time a name is used.
2. Sign in as `admin` to get the *Add a book* form.
3. On the library page you can **Borrow** an available book, **Return** one you have, or **Join wait list** for one someone else has.
4. Your borrowed books and wait-list positions are shown at the bottom.
5. If a book you were waiting for comes back, it's yours automatically and you're told on your next sign-in.
6. **Sign out** is in the top-right corner.

### How the spec commands map to the app

| Command | In the UI | API |
|---|---|---|
| `login [name]` | Sign-in page | `POST /api/sessions` |
| `add [book_name]` | *Add a book* form (admin only) | `POST /api/books` |
| `list` | Book list | `GET /api/books` |
| `borrow [book_name]` | Borrow button | `POST /api/loans` |
| `return [book_name]` | Return button | `POST /api/returns` |
| `waitlist [book_name]` | Join wait list button | `POST /api/waitlist-entries` |
| `status` | *Your borrowed books* / *Your wait lists* | `GET /api/members/me/status` |
| `logout` | Sign out button | `DELETE /api/sessions/current` |

Every endpoint except sign-in needs `Authorization: Bearer <token>`, using the token returned by `POST /api/sessions`.

## Tests

```sh
./mvnw verify                        # builds the frontend, runs the backend tests (+ JaCoCo report in target/site/jacoco)
npm --prefix frontend run test:ci    # frontend unit tests in headless Chrome
npm --prefix frontend run e2e        # the spec's example session clicked through the UI (run ./mvnw package first)
```

The frontend commands need Node.js 20.19+ / 22.12+ / 24+ on your PATH and Google Chrome installed. To run only the backend tests without rebuilding the frontend, add `-Dskip.installnodenpm -Dskip.npm` to the Maven command.

- Domain and service tests use the real in-memory storage rather than mocks, so they check behaviour rather than wiring.
- `ExampleSessionIntegrationTest` replays the example session from the spec against the REST API, line by line.
- `InputHandlingIntegrationTest` covers validation messages and titles with apostrophes, quotes and accents.
- Controller tests run each controller against the real services and in-memory storage (a fresh library per test), so they check status codes and error text for real situations rather than stubbed ones. Nothing in the backend tests is mocked.
- `ConcurrencyTest` has 16 threads borrow the same book (exactly one wins) and join the same wait list (positions 1–16, no duplicates).
- `ArchitectureTest` stops the domain/application code from depending on Spring or on the web layer.

## Code layout

```text
src/main/java/com/smbc/library
  domain/          Book, Waitlist, Member, Username, BookTitle and the rules around them
  application/     One service per area: membership, catalog, lending, wait list, status
  infrastructure/  In-memory storage, sessions, locking and Spring wiring
  web/             Controllers, DTOs and error handling
src/main/resources messages.properties holds every user-facing message
frontend/          Angular app
```

## Decisions and assumptions

- **Web UI instead of a CLI.** The spec allows either. I kept the spec's wording for all messages so the example session still reads the same.
- **Names and titles are case-insensitive** and extra spaces are ignored, so `alice` and `Alice` are the same person. Treating them as two members seemed more like a bug than a feature. The first spelling is kept for display.
- **One copy per title.** The spec never mentions copies, and the example (Bob can't borrow 1984 while Alice has it) only works with one.
- **Borrowed books stay in the list, marked "(borrowed)".** That's what the example's `list` output shows, even though the command description says borrowed books disappear. I went with the example.
- **A returned book goes straight to the first person waiting**, and everyone else moves up a place. This matches the example where Bob logs in and already has 1984.
- **The greeting is still shown on the hand-over login.** The example skips "Hello, Bob!" there, but every other login greets, so leaving it out looked accidental.
- **`admin` can borrow too.** Nothing in the spec says otherwise.
- **Things I reject with a message:** borrowing a book you already have, waiting for a book you hold or one that's available, joining the same wait list twice, and adding a title that already exists.
- **Limits:** names up to 50 characters, titles up to 200.
- **Status codes:** 401 when not signed in, 403 when a non-admin tries to add a book, 404 for unknown books, 409 for rule violations.
- **Sessions** last until sign-out, a restart, or 30 minutes without use (`SESSION_IDLE_TIMEOUT=1h ./start.sh` to change it). Without the timeout, members who close the tab without signing out would leave sessions behind for as long as the server runs.
- **Concurrency:** the web server handles requests on multiple threads, so every change runs under a write lock (`ReadWriteLockUnitOfWork`). Without it, two people could borrow the same book at once.
- **Storage is behind repository interfaces.** The in-memory repositories happen to return live objects, but the services still call `save()` after every change, so swapping in a real database only means writing new repository classes.
- **Sessions and locking are behind small interfaces too** (`SessionRegistry`, `UnitOfWork`). Each has one implementation; the interfaces are there so the application layer never imports infrastructure code, which `ArchitectureTest` checks.
- **Input is validated once, in the domain** (`Username`, `BookTitle`), after trimming and collapsing spaces. The Angular forms check the same limits so most mistakes never reach the server.
- **Status scans all books** rather than keeping a per-member index. It's simpler and can't go out of sync, and it's fast enough for a library this size.

## Troubleshooting

| Problem | Fix |
|---|---|
| Port 8080 already in use | Stop the other app or run `PORT=9090 ./start.sh` |
| "Java 21 or newer is required" | Install a JDK 21+ (e.g. Temurin) and open a new terminal |
| The build fails with a network error | Check the connection and run `./start.sh` again |
| `./start.sh: Permission denied` | Run `sh start.sh` |
| Build fails on Windows with "Unable to rename library.jar" | The app is still running from that jar; stop it first |
| Signed out after restarting or after a long break | Expected: restart clears all data and sessions, and sessions end after 30 minutes without use |
